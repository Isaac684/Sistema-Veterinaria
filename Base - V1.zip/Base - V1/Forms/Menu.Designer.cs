﻿namespace Base___V1
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            PnlFormLoader = new Panel();
            panel1 = new Panel();
            panel4 = new Panel();
            textBox1 = new TextBox();
            pictureBox2 = new PictureBox();
            IblTittle = new Label();
            PanelNav = new Panel();
            Btn6 = new Button();
            Btn1 = new Button();
            btnInv = new Button();
            button1 = new Button();
            Btn2 = new Button();
            btnCita = new Button();
            sideBarContainer = new FlowLayoutPanel();
            panel2 = new Panel();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            btnMenu = new PictureBox();
            panel3 = new Panel();
            panel7 = new Panel();
            panel8 = new Panel();
            panel5 = new Panel();
            panel6 = new Panel();
            panel9 = new Panel();
            sidebarTimer = new System.Windows.Forms.Timer(components);
            panel1.SuspendLayout();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            sideBarContainer.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)btnMenu).BeginInit();
            panel3.SuspendLayout();
            panel7.SuspendLayout();
            panel8.SuspendLayout();
            panel5.SuspendLayout();
            panel6.SuspendLayout();
            panel9.SuspendLayout();
            SuspendLayout();
            // 
            // PnlFormLoader
            // 
            PnlFormLoader.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            PnlFormLoader.BackColor = Color.Transparent;
            PnlFormLoader.Location = new Point(197, 61);
            PnlFormLoader.Margin = new Padding(3, 2, 3, 2);
            PnlFormLoader.Name = "PnlFormLoader";
            PnlFormLoader.Size = new Size(839, 585);
            PnlFormLoader.TabIndex = 0;
            // 
            // panel1
            // 
            panel1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel1.BackColor = Color.FromArgb(208, 227, 235);
            panel1.Controls.Add(panel4);
            panel1.Controls.Add(IblTittle);
            panel1.Controls.Add(PanelNav);
            panel1.Location = new Point(197, 0);
            panel1.Margin = new Padding(3, 2, 3, 2);
            panel1.Name = "panel1";
            panel1.Size = new Size(839, 62);
            panel1.TabIndex = 1;
            // 
            // panel4
            // 
            panel4.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            panel4.BackColor = Color.White;
            panel4.Controls.Add(textBox1);
            panel4.Controls.Add(pictureBox2);
            panel4.Location = new Point(601, 12);
            panel4.Name = "panel4";
            panel4.Size = new Size(226, 37);
            panel4.TabIndex = 8;
            // 
            // textBox1
            // 
            textBox1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox1.BackColor = Color.White;
            textBox1.BorderStyle = BorderStyle.None;
            textBox1.Cursor = Cursors.IBeam;
            textBox1.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox1.ForeColor = Color.Black;
            textBox1.Location = new Point(24, 3);
            textBox1.Margin = new Padding(9, 8, 9, 8);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "Buscar por";
            textBox1.Size = new Size(199, 31);
            textBox1.TabIndex = 8;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(3, 7);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(21, 24);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 0;
            pictureBox2.TabStop = false;
            // 
            // IblTittle
            // 
            IblTittle.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            IblTittle.BackColor = Color.FromArgb(1, 48, 69);
            IblTittle.Font = new Font("Nirmala UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            IblTittle.ForeColor = Color.White;
            IblTittle.Location = new Point(0, 0);
            IblTittle.Name = "IblTittle";
            IblTittle.Size = new Size(837, 59);
            IblTittle.TabIndex = 1;
            IblTittle.Text = "Administración";
            IblTittle.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // PanelNav
            // 
            PanelNav.BackColor = Color.FromArgb(0, 126, 249);
            PanelNav.Location = new Point(0, 163);
            PanelNav.Margin = new Padding(3, 2, 3, 2);
            PanelNav.Name = "PanelNav";
            PanelNav.Size = new Size(175, 5);
            PanelNav.TabIndex = 7;
            // 
            // Btn6
            // 
            Btn6.BackColor = Color.FromArgb(1, 48, 69);
            Btn6.Cursor = Cursors.Hand;
            Btn6.Dock = DockStyle.Fill;
            Btn6.FlatAppearance.BorderSize = 0;
            Btn6.FlatStyle = FlatStyle.Flat;
            Btn6.Font = new Font("Nirmala UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn6.ForeColor = Color.White;
            Btn6.Image = (Image)resources.GetObject("Btn6.Image");
            Btn6.ImageAlign = ContentAlignment.MiddleLeft;
            Btn6.Location = new Point(0, 0);
            Btn6.Margin = new Padding(3, 2, 3, 2);
            Btn6.Name = "Btn6";
            Btn6.Padding = new Padding(5, 0, 0, 0);
            Btn6.Size = new Size(214, 49);
            Btn6.TabIndex = 6;
            Btn6.Text = "Configurar PIN";
            Btn6.UseVisualStyleBackColor = false;
            Btn6.Click += Btn6_Click;
            // 
            // Btn1
            // 
            Btn1.BackColor = Color.FromArgb(1, 48, 69);
            Btn1.Cursor = Cursors.Hand;
            Btn1.Dock = DockStyle.Fill;
            Btn1.FlatAppearance.BorderSize = 0;
            Btn1.FlatStyle = FlatStyle.Flat;
            Btn1.Font = new Font("Nirmala UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn1.ForeColor = Color.White;
            Btn1.Image = (Image)resources.GetObject("Btn1.Image");
            Btn1.ImageAlign = ContentAlignment.MiddleLeft;
            Btn1.Location = new Point(0, 0);
            Btn1.Margin = new Padding(3, 2, 3, 2);
            Btn1.Name = "Btn1";
            Btn1.Padding = new Padding(5, 0, 0, 0);
            Btn1.Size = new Size(214, 49);
            Btn1.TabIndex = 1;
            Btn1.Text = "Administración";
            Btn1.UseVisualStyleBackColor = false;
            Btn1.Click += Btn1_Click;
            // 
            // btnInv
            // 
            btnInv.BackColor = Color.FromArgb(1, 48, 69);
            btnInv.Cursor = Cursors.Hand;
            btnInv.Dock = DockStyle.Fill;
            btnInv.FlatAppearance.BorderSize = 0;
            btnInv.FlatStyle = FlatStyle.Flat;
            btnInv.Font = new Font("Nirmala UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnInv.ForeColor = Color.White;
            btnInv.Image = (Image)resources.GetObject("btnInv.Image");
            btnInv.ImageAlign = ContentAlignment.MiddleLeft;
            btnInv.Location = new Point(0, 0);
            btnInv.Margin = new Padding(3, 2, 3, 2);
            btnInv.Name = "btnInv";
            btnInv.Padding = new Padding(5, 0, 0, 0);
            btnInv.Size = new Size(214, 49);
            btnInv.TabIndex = 10;
            btnInv.Text = "Inventario";
            btnInv.UseVisualStyleBackColor = false;
            btnInv.Click += button1_Click_1;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(1, 48, 69);
            button1.Cursor = Cursors.Hand;
            button1.Dock = DockStyle.Fill;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Nirmala UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.Image = (Image)resources.GetObject("button1.Image");
            button1.ImageAlign = ContentAlignment.MiddleLeft;
            button1.Location = new Point(0, 0);
            button1.Margin = new Padding(3, 2, 3, 2);
            button1.Name = "button1";
            button1.Padding = new Padding(5, 0, 0, 0);
            button1.Size = new Size(214, 49);
            button1.TabIndex = 11;
            button1.Text = "Ventas";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click_2;
            // 
            // Btn2
            // 
            Btn2.BackColor = Color.FromArgb(1, 48, 69);
            Btn2.Cursor = Cursors.Hand;
            Btn2.Dock = DockStyle.Fill;
            Btn2.FlatAppearance.BorderSize = 0;
            Btn2.FlatStyle = FlatStyle.Flat;
            Btn2.Font = new Font("Nirmala UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn2.ForeColor = Color.White;
            Btn2.Image = (Image)resources.GetObject("Btn2.Image");
            Btn2.ImageAlign = ContentAlignment.MiddleLeft;
            Btn2.Location = new Point(0, 0);
            Btn2.Margin = new Padding(3, 2, 3, 2);
            Btn2.Name = "Btn2";
            Btn2.Padding = new Padding(5, 0, 0, 0);
            Btn2.Size = new Size(214, 49);
            Btn2.TabIndex = 2;
            Btn2.Text = "Agregar paciente";
            Btn2.UseVisualStyleBackColor = false;
            Btn2.Click += Btn2_Click;
            // 
            // btnCita
            // 
            btnCita.BackColor = Color.FromArgb(1, 48, 69);
            btnCita.Cursor = Cursors.Hand;
            btnCita.Dock = DockStyle.Fill;
            btnCita.FlatAppearance.BorderSize = 0;
            btnCita.FlatStyle = FlatStyle.Flat;
            btnCita.Font = new Font("Nirmala UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCita.ForeColor = Color.White;
            btnCita.Image = (Image)resources.GetObject("btnCita.Image");
            btnCita.ImageAlign = ContentAlignment.MiddleLeft;
            btnCita.Location = new Point(0, 0);
            btnCita.Margin = new Padding(3, 2, 3, 2);
            btnCita.Name = "btnCita";
            btnCita.Padding = new Padding(5, 0, 0, 0);
            btnCita.Size = new Size(214, 49);
            btnCita.TabIndex = 9;
            btnCita.Text = "Agendar cita";
            btnCita.UseVisualStyleBackColor = false;
            btnCita.Click += btnCita_Click;
            // 
            // sideBarContainer
            // 
            sideBarContainer.BackColor = Color.FromArgb(1, 48, 69);
            sideBarContainer.Controls.Add(panel2);
            sideBarContainer.Controls.Add(panel3);
            sideBarContainer.Controls.Add(panel7);
            sideBarContainer.Controls.Add(panel8);
            sideBarContainer.Controls.Add(panel5);
            sideBarContainer.Controls.Add(panel6);
            sideBarContainer.Controls.Add(panel9);
            sideBarContainer.Dock = DockStyle.Left;
            sideBarContainer.Location = new Point(0, 0);
            sideBarContainer.MaximumSize = new Size(197, 0);
            sideBarContainer.MinimumSize = new Size(56, 0);
            sideBarContainer.Name = "sideBarContainer";
            sideBarContainer.Size = new Size(197, 646);
            sideBarContainer.TabIndex = 2;
            // 
            // panel2
            // 
            panel2.Controls.Add(pictureBox1);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(btnMenu);
            panel2.Location = new Point(3, 3);
            panel2.Name = "panel2";
            panel2.Size = new Size(214, 142);
            panel2.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Image = Properties.Resources.Logo_Recortado;
            pictureBox1.Location = new Point(68, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(59, 59);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Nirmala UI", 10.2F, FontStyle.Bold);
            label1.ForeColor = Color.White;
            label1.Location = new Point(53, 100);
            label1.Name = "label1";
            label1.Size = new Size(46, 19);
            label1.TabIndex = 1;
            label1.Text = "Menu";
            // 
            // btnMenu
            // 
            btnMenu.Cursor = Cursors.Hand;
            btnMenu.Image = (Image)resources.GetObject("btnMenu.Image");
            btnMenu.Location = new Point(0, 82);
            btnMenu.Name = "btnMenu";
            btnMenu.Size = new Size(47, 49);
            btnMenu.SizeMode = PictureBoxSizeMode.StretchImage;
            btnMenu.TabIndex = 0;
            btnMenu.TabStop = false;
            btnMenu.Click += btnMenu_Click;
            // 
            // panel3
            // 
            panel3.Controls.Add(Btn1);
            panel3.Location = new Point(3, 151);
            panel3.Name = "panel3";
            panel3.Size = new Size(214, 49);
            panel3.TabIndex = 1;
            // 
            // panel7
            // 
            panel7.Controls.Add(Btn2);
            panel7.Location = new Point(3, 206);
            panel7.Name = "panel7";
            panel7.Size = new Size(214, 49);
            panel7.TabIndex = 2;
            // 
            // panel8
            // 
            panel8.Controls.Add(btnCita);
            panel8.Location = new Point(3, 261);
            panel8.Name = "panel8";
            panel8.Size = new Size(214, 49);
            panel8.TabIndex = 3;
            // 
            // panel5
            // 
            panel5.Controls.Add(btnInv);
            panel5.Location = new Point(3, 316);
            panel5.Name = "panel5";
            panel5.Size = new Size(214, 49);
            panel5.TabIndex = 2;
            // 
            // panel6
            // 
            panel6.Controls.Add(button1);
            panel6.Location = new Point(3, 371);
            panel6.Name = "panel6";
            panel6.Size = new Size(214, 49);
            panel6.TabIndex = 2;
            // 
            // panel9
            // 
            panel9.Controls.Add(Btn6);
            panel9.Location = new Point(3, 426);
            panel9.Name = "panel9";
            panel9.Size = new Size(214, 49);
            panel9.TabIndex = 12;
            // 
            // sidebarTimer
            // 
            sidebarTimer.Interval = 10;
            sidebarTimer.Tick += sidebarTimer_Tick;
            // 
            // Menu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1036, 646);
            Controls.Add(sideBarContainer);
            Controls.Add(panel1);
            Controls.Add(PnlFormLoader);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Margin = new Padding(3, 2, 3, 2);
            MinimumSize = new Size(1052, 681);
            Name = "Menu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Menu";
            FormClosing += Form1_FormClosing;
            FormClosed += Form1_FormClosed;
            panel1.ResumeLayout(false);
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            sideBarContainer.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)btnMenu).EndInit();
            panel3.ResumeLayout(false);
            panel7.ResumeLayout(false);
            panel8.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel6.ResumeLayout(false);
            panel9.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        public Panel PnlFormLoader;
        private Panel panel1;
        private Panel panel4;
        public TextBox textBox1;
        private PictureBox pictureBox2;
        private Panel PanelNav;
        private Button Btn6;
        public Button Btn2;
        private Button Btn1;
        private Label IblTittle;
		public Button btnCita;
		public Button btnInv;
		public Button button1;
        private FlowLayoutPanel sideBarContainer;
        private Panel panel2;
        private Panel panel3;
        private Panel panel5;
        private Panel panel6;
        private Panel panel7;
        private Panel panel8;
        private Panel panel9;
        private PictureBox btnMenu;
        private Label label1;
        private System.Windows.Forms.Timer sidebarTimer;
        private PictureBox pictureBox1;
    }
}