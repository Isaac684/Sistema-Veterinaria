﻿namespace Base___V1.Forms.InternalViews
{
	partial class AgregarProducto
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            button2 = new Button();
            tableLayoutPanel2 = new TableLayoutPanel();
            button1 = new Button();
            tableLayoutPanel1 = new TableLayoutPanel();
            tableLayoutPanel3 = new TableLayoutPanel();
            txt7 = new TextBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            txt1 = new TextBox();
            txt2 = new TextBox();
            txt6 = new TextBox();
            txt4 = new TextBox();
            txt5 = new TextBox();
            tableLayoutPanel4 = new TableLayoutPanel();
            label8 = new Label();
            txt3 = new TextBox();
            tableLayoutPanel2.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            tableLayoutPanel3.SuspendLayout();
            tableLayoutPanel4.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(31, 38, 67);
            label1.Dock = DockStyle.Fill;
            label1.Font = new Font("Calibri", 14F, FontStyle.Bold);
            label1.ForeColor = Color.White;
            label1.Location = new Point(3, 0);
            label1.Name = "label1";
            label1.Size = new Size(670, 42);
            label1.TabIndex = 11;
            label1.Text = "Nuevo producto";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // button2
            // 
            button2.BackColor = Color.DimGray;
            button2.Dock = DockStyle.Fill;
            button2.FlatStyle = FlatStyle.Flat;
            button2.ForeColor = SystemColors.Control;
            button2.Location = new Point(360, 2);
            button2.Margin = new Padding(3, 2, 3, 2);
            button2.Name = "button2";
            button2.Size = new Size(156, 31);
            button2.TabIndex = 2;
            button2.Text = "Cancelar";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 3;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 68.7861252F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 31.2138729F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 150F));
            tableLayoutPanel2.Controls.Add(button2, 1, 0);
            tableLayoutPanel2.Controls.Add(button1, 2, 0);
            tableLayoutPanel2.Location = new Point(3, 307);
            tableLayoutPanel2.Margin = new Padding(3, 2, 3, 2);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 1;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.Size = new Size(670, 35);
            tableLayoutPanel2.TabIndex = 14;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(31, 38, 67);
            button1.Dock = DockStyle.Fill;
            button1.FlatStyle = FlatStyle.Flat;
            button1.ForeColor = SystemColors.Control;
            button1.Location = new Point(522, 2);
            button1.Margin = new Padding(3, 2, 3, 2);
            button1.Name = "button1";
            button1.Size = new Size(145, 31);
            button1.TabIndex = 3;
            button1.Text = "Aceptar";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.BackColor = Color.White;
            tableLayoutPanel1.ColumnCount = 1;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Controls.Add(label1, 0, 0);
            tableLayoutPanel1.Controls.Add(tableLayoutPanel3, 0, 2);
            tableLayoutPanel1.Controls.Add(tableLayoutPanel2, 0, 4);
            tableLayoutPanel1.Controls.Add(tableLayoutPanel4, 0, 3);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Margin = new Padding(3, 2, 3, 2);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 5;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 77.5F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 22.5F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 214F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 37F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 38F));
            tableLayoutPanel1.Size = new Size(676, 344);
            tableLayoutPanel1.TabIndex = 2;
            tableLayoutPanel1.Paint += tableLayoutPanel1_Paint;
            // 
            // tableLayoutPanel3
            // 
            tableLayoutPanel3.ColumnCount = 4;
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 32.89817F));
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 67.10183F));
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 116F));
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 220F));
            tableLayoutPanel3.Controls.Add(txt7, 3, 2);
            tableLayoutPanel3.Controls.Add(label2, 0, 0);
            tableLayoutPanel3.Controls.Add(label3, 2, 0);
            tableLayoutPanel3.Controls.Add(label4, 0, 1);
            tableLayoutPanel3.Controls.Add(label7, 2, 1);
            tableLayoutPanel3.Controls.Add(label6, 2, 2);
            tableLayoutPanel3.Controls.Add(label5, 0, 2);
            tableLayoutPanel3.Controls.Add(txt1, 1, 0);
            tableLayoutPanel3.Controls.Add(txt2, 1, 1);
            tableLayoutPanel3.Controls.Add(txt6, 1, 2);
            tableLayoutPanel3.Controls.Add(txt4, 3, 0);
            tableLayoutPanel3.Controls.Add(txt5, 3, 1);
            tableLayoutPanel3.Location = new Point(3, 56);
            tableLayoutPanel3.Margin = new Padding(3, 2, 3, 2);
            tableLayoutPanel3.Name = "tableLayoutPanel3";
            tableLayoutPanel3.RowCount = 3;
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Absolute, 67F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Absolute, 15F));
            tableLayoutPanel3.Size = new Size(670, 201);
            tableLayoutPanel3.TabIndex = 15;
            // 
            // txt7
            // 
            txt7.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            txt7.Location = new Point(452, 156);
            txt7.Margin = new Padding(3, 2, 3, 2);
            txt7.Name = "txt7";
            txt7.Size = new Size(215, 23);
            txt7.TabIndex = 28;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(3, 0);
            label2.Name = "label2";
            label2.Size = new Size(103, 67);
            label2.TabIndex = 13;
            label2.Text = "Codigo";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Black;
            label3.Location = new Point(336, 0);
            label3.Name = "label3";
            label3.Size = new Size(110, 67);
            label3.TabIndex = 15;
            label3.Text = "Cantidad";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Black;
            label4.Location = new Point(3, 67);
            label4.Name = "label4";
            label4.Size = new Size(103, 67);
            label4.TabIndex = 17;
            label4.Text = "Nombre";
            label4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label7.AutoSize = true;
            label7.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.Black;
            label7.Location = new Point(336, 67);
            label7.Name = "label7";
            label7.Size = new Size(110, 67);
            label7.TabIndex = 22;
            label7.Text = "Costo de compra";
            label7.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label6.AutoSize = true;
            label6.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.Black;
            label6.Location = new Point(336, 134);
            label6.Name = "label6";
            label6.Size = new Size(110, 67);
            label6.TabIndex = 20;
            label6.Text = "Aviso de stock minimo";
            label6.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label5.AutoSize = true;
            label5.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.Black;
            label5.Location = new Point(3, 134);
            label5.Name = "label5";
            label5.Size = new Size(103, 67);
            label5.TabIndex = 19;
            label5.Text = "Precio de venta";
            label5.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // txt1
            // 
            txt1.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            txt1.Location = new Point(112, 22);
            txt1.Margin = new Padding(3, 2, 3, 2);
            txt1.Name = "txt1";
            txt1.Size = new Size(218, 23);
            txt1.TabIndex = 23;
            // 
            // txt2
            // 
            txt2.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            txt2.Location = new Point(112, 89);
            txt2.Margin = new Padding(3, 2, 3, 2);
            txt2.Name = "txt2";
            txt2.Size = new Size(218, 23);
            txt2.TabIndex = 24;
            // 
            // txt6
            // 
            txt6.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            txt6.Location = new Point(112, 156);
            txt6.Margin = new Padding(3, 2, 3, 2);
            txt6.Name = "txt6";
            txt6.Size = new Size(218, 23);
            txt6.TabIndex = 25;
            // 
            // txt4
            // 
            txt4.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            txt4.Location = new Point(452, 22);
            txt4.Margin = new Padding(3, 2, 3, 2);
            txt4.Name = "txt4";
            txt4.Size = new Size(215, 23);
            txt4.TabIndex = 26;
            // 
            // txt5
            // 
            txt5.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            txt5.Location = new Point(452, 89);
            txt5.Margin = new Padding(3, 2, 3, 2);
            txt5.Name = "txt5";
            txt5.Size = new Size(215, 23);
            txt5.TabIndex = 27;
            // 
            // tableLayoutPanel4
            // 
            tableLayoutPanel4.ColumnCount = 2;
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 19.2959576F));
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 80.70404F));
            tableLayoutPanel4.Controls.Add(label8, 0, 0);
            tableLayoutPanel4.Controls.Add(txt3, 1, 0);
            tableLayoutPanel4.Location = new Point(3, 270);
            tableLayoutPanel4.Margin = new Padding(3, 2, 3, 2);
            tableLayoutPanel4.Name = "tableLayoutPanel4";
            tableLayoutPanel4.RowCount = 1;
            tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel4.Size = new Size(670, 32);
            tableLayoutPanel4.TabIndex = 16;
            // 
            // label8
            // 
            label8.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label8.AutoSize = true;
            label8.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.Black;
            label8.Location = new Point(3, 0);
            label8.Name = "label8";
            label8.Size = new Size(123, 32);
            label8.TabIndex = 21;
            label8.Text = "Descripcion";
            label8.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // txt3
            // 
            txt3.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            txt3.Location = new Point(132, 4);
            txt3.Margin = new Padding(3, 2, 3, 2);
            txt3.Name = "txt3";
            txt3.Size = new Size(535, 23);
            txt3.TabIndex = 22;
            // 
            // AgregarProducto
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(676, 344);
            Controls.Add(tableLayoutPanel1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 2, 3, 2);
            Name = "AgregarProducto";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Agregar_producto";
            tableLayoutPanel2.ResumeLayout(false);
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            tableLayoutPanel3.ResumeLayout(false);
            tableLayoutPanel3.PerformLayout();
            tableLayoutPanel4.ResumeLayout(false);
            tableLayoutPanel4.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Label label1;
		private Button button2;
		private TableLayoutPanel tableLayoutPanel2;
		private Button button1;
		private TableLayoutPanel tableLayoutPanel1;
		private TableLayoutPanel tableLayoutPanel3;
		private Label label5;
		private Label label2;
		private Label label3;
		private Label label4;
		private Label label6;
		private Label label7;
		private TableLayoutPanel tableLayoutPanel4;
		private Label label8;
		private TextBox txt7;
		private TextBox txt1;
		private TextBox txt2;
		private TextBox txt6;
		private TextBox txt4;
		private TextBox txt5;
		private TextBox txt3;
	}
}