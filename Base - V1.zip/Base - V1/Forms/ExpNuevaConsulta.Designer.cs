﻿namespace Base___V1
{
    partial class ExpNuevaConsulta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ExpNuevaConsulta));
            lblNombrePaciente = new Label();
            lblDatosPaciente = new Label();
            checkVacuna = new CheckBox();
            checkRabia = new CheckBox();
            checkQuintuple = new CheckBox();
            checkParvovirus = new CheckBox();
            checkGiardia = new CheckBox();
            checkTriFelina = new CheckBox();
            checkBordetella = new CheckBox();
            checkLeucemia = new CheckBox();
            labelOtros = new Label();
            textBox2 = new TextBox();
            panel1 = new Panel();
            btnMin1 = new PictureBox();
            textBox1 = new TextBox();
            label1 = new Label();
            dateTimePicker2 = new DateTimePicker();
            checkGarrapatas = new CheckBox();
            label2 = new Label();
            txtMedicina = new TextBox();
            labelMedi = new Label();
            dateTimePicker1 = new DateTimePicker();
            checkParasitos = new CheckBox();
            labelParasitos = new Label();
            panel2 = new Panel();
            btnMin2 = new PictureBox();
            textBox4 = new TextBox();
            label8 = new Label();
            textBox6 = new TextBox();
            label7 = new Label();
            txtBoxTenencia = new TextBox();
            txtBoxMascotas = new TextBox();
            txtBoxDieta = new TextBox();
            label6 = new Label();
            txtEnfermedades = new TextBox();
            label4 = new Label();
            textBox3 = new TextBox();
            label3 = new Label();
            checkBox1 = new CheckBox();
            label5 = new Label();
            checkAcceso = new CheckBox();
            labelTenencia = new Label();
            panel3 = new Panel();
            panel10 = new Panel();
            btnMin10 = new PictureBox();
            label46 = new Label();
            label47 = new Label();
            textBox32 = new TextBox();
            label45 = new Label();
            textBox31 = new TextBox();
            checkBox13 = new CheckBox();
            label44 = new Label();
            textBox30 = new TextBox();
            checkBox12 = new CheckBox();
            label43 = new Label();
            textBox37 = new TextBox();
            textBox29 = new TextBox();
            label52 = new Label();
            label42 = new Label();
            textBox38 = new TextBox();
            textBox28 = new TextBox();
            label53 = new Label();
            label38 = new Label();
            textBox39 = new TextBox();
            textBox25 = new TextBox();
            label54 = new Label();
            label48 = new Label();
            textBox35 = new TextBox();
            textBox33 = new TextBox();
            label50 = new Label();
            label49 = new Label();
            textBox36 = new TextBox();
            textBox34 = new TextBox();
            label51 = new Label();
            panel9 = new Panel();
            btnMin9 = new PictureBox();
            textBox26 = new TextBox();
            label41 = new Label();
            label40 = new Label();
            textBox27 = new TextBox();
            label39 = new Label();
            checkBox7 = new CheckBox();
            label37 = new Label();
            textBox24 = new TextBox();
            checkBox6 = new CheckBox();
            label35 = new Label();
            textBox22 = new TextBox();
            label32 = new Label();
            textBox20 = new TextBox();
            label36 = new Label();
            textBox23 = new TextBox();
            panel8 = new Panel();
            btnMin8 = new PictureBox();
            label33 = new Label();
            label34 = new Label();
            textBox21 = new TextBox();
            label31 = new Label();
            textBox19 = new TextBox();
            label30 = new Label();
            textBox18 = new TextBox();
            panel7 = new Panel();
            btnMin7 = new PictureBox();
            label27 = new Label();
            label28 = new Label();
            textBox16 = new TextBox();
            label26 = new Label();
            textBox15 = new TextBox();
            label25 = new Label();
            textBox14 = new TextBox();
            label24 = new Label();
            textBox13 = new TextBox();
            label29 = new Label();
            textBox17 = new TextBox();
            panel6 = new Panel();
            btnMin6 = new PictureBox();
            label19 = new Label();
            label20 = new Label();
            textBox9 = new TextBox();
            label16 = new Label();
            textBox8 = new TextBox();
            label14 = new Label();
            textBox5 = new TextBox();
            checkBox2 = new CheckBox();
            label15 = new Label();
            textBox7 = new TextBox();
            label22 = new Label();
            textBox11 = new TextBox();
            checkBox11 = new CheckBox();
            label21 = new Label();
            textBox10 = new TextBox();
            label23 = new Label();
            textBox12 = new TextBox();
            checkBox3 = new CheckBox();
            checkBox4 = new CheckBox();
            checkBox5 = new CheckBox();
            panel5 = new Panel();
            btnMin5 = new PictureBox();
            label17 = new Label();
            label18 = new Label();
            txtBoxMovimiento = new TextBox();
            panel4 = new Panel();
            btnMin4 = new PictureBox();
            txtBoxLesiones = new TextBox();
            label10 = new Label();
            label9 = new Label();
            txtboxAspecto = new TextBox();
            label11 = new Label();
            label12 = new Label();
            txtBoxAlopecia = new TextBox();
            label13 = new Label();
            txtBoxParasitos = new TextBox();
            button1 = new Button();
            cbEditar = new CheckBox();
            btnNewConsulta = new Button();
            label55 = new Label();
            txtBoxMotivoConsulta = new TextBox();
            timer1 = new System.Windows.Forms.Timer(components);
            timer2 = new System.Windows.Forms.Timer(components);
            timer3 = new System.Windows.Forms.Timer(components);
            timer4 = new System.Windows.Forms.Timer(components);
            timer5 = new System.Windows.Forms.Timer(components);
            timer6 = new System.Windows.Forms.Timer(components);
            timer7 = new System.Windows.Forms.Timer(components);
            timer8 = new System.Windows.Forms.Timer(components);
            timer9 = new System.Windows.Forms.Timer(components);
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)btnMin1).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)btnMin2).BeginInit();
            panel3.SuspendLayout();
            panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)btnMin10).BeginInit();
            panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)btnMin9).BeginInit();
            panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)btnMin8).BeginInit();
            panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)btnMin7).BeginInit();
            panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)btnMin6).BeginInit();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)btnMin5).BeginInit();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)btnMin4).BeginInit();
            SuspendLayout();
            // 
            // lblNombrePaciente
            // 
            lblNombrePaciente.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblNombrePaciente.ForeColor = Color.Black;
            lblNombrePaciente.Location = new Point(219, 7);
            lblNombrePaciente.Name = "lblNombrePaciente";
            lblNombrePaciente.Size = new Size(340, 32);
            lblNombrePaciente.TabIndex = 63;
            lblNombrePaciente.Text = "Nombre del chucho";
            // 
            // lblDatosPaciente
            // 
            lblDatosPaciente.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblDatosPaciente.ForeColor = Color.Black;
            lblDatosPaciente.Location = new Point(10, 7);
            lblDatosPaciente.Name = "lblDatosPaciente";
            lblDatosPaciente.Size = new Size(224, 32);
            lblDatosPaciente.TabIndex = 62;
            lblDatosPaciente.Text = "Nueva consulta:";
            // 
            // checkVacuna
            // 
            checkVacuna.AutoSize = true;
            checkVacuna.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkVacuna.ForeColor = Color.Black;
            checkVacuna.Location = new Point(24, 48);
            checkVacuna.Margin = new Padding(3, 2, 3, 2);
            checkVacuna.Name = "checkVacuna";
            checkVacuna.RightToLeft = RightToLeft.Yes;
            checkVacuna.Size = new Size(87, 22);
            checkVacuna.TabIndex = 64;
            checkVacuna.Text = "Vacunas";
            checkVacuna.TextAlign = ContentAlignment.MiddleCenter;
            checkVacuna.UseVisualStyleBackColor = true;
            // 
            // checkRabia
            // 
            checkRabia.AutoSize = true;
            checkRabia.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkRabia.ForeColor = Color.Black;
            checkRabia.Location = new Point(264, 48);
            checkRabia.Margin = new Padding(3, 2, 3, 2);
            checkRabia.Name = "checkRabia";
            checkRabia.RightToLeft = RightToLeft.Yes;
            checkRabia.Size = new Size(69, 22);
            checkRabia.TabIndex = 65;
            checkRabia.Text = "Rabia";
            checkRabia.TextAlign = ContentAlignment.MiddleCenter;
            checkRabia.UseVisualStyleBackColor = true;
            // 
            // checkQuintuple
            // 
            checkQuintuple.AutoSize = true;
            checkQuintuple.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkQuintuple.ForeColor = Color.Black;
            checkQuintuple.Location = new Point(145, 47);
            checkQuintuple.Margin = new Padding(3, 2, 3, 2);
            checkQuintuple.Name = "checkQuintuple";
            checkQuintuple.RightToLeft = RightToLeft.Yes;
            checkQuintuple.Size = new Size(92, 22);
            checkQuintuple.TabIndex = 66;
            checkQuintuple.Text = "Quintuple";
            checkQuintuple.TextAlign = ContentAlignment.MiddleCenter;
            checkQuintuple.UseVisualStyleBackColor = true;
            // 
            // checkParvovirus
            // 
            checkParvovirus.AutoSize = true;
            checkParvovirus.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkParvovirus.ForeColor = Color.Black;
            checkParvovirus.Location = new Point(9, 82);
            checkParvovirus.Margin = new Padding(3, 2, 3, 2);
            checkParvovirus.Name = "checkParvovirus";
            checkParvovirus.RightToLeft = RightToLeft.Yes;
            checkParvovirus.Size = new Size(100, 22);
            checkParvovirus.TabIndex = 67;
            checkParvovirus.Text = "Parvovirus";
            checkParvovirus.TextAlign = ContentAlignment.MiddleCenter;
            checkParvovirus.UseVisualStyleBackColor = true;
            // 
            // checkGiardia
            // 
            checkGiardia.AutoSize = true;
            checkGiardia.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkGiardia.ForeColor = Color.White;
            checkGiardia.Location = new Point(352, 45);
            checkGiardia.Margin = new Padding(3, 2, 3, 2);
            checkGiardia.Name = "checkGiardia";
            checkGiardia.RightToLeft = RightToLeft.Yes;
            checkGiardia.Size = new Size(79, 22);
            checkGiardia.TabIndex = 68;
            checkGiardia.Text = "Giardia";
            checkGiardia.TextAlign = ContentAlignment.MiddleCenter;
            checkGiardia.UseVisualStyleBackColor = true;
            // 
            // checkTriFelina
            // 
            checkTriFelina.AutoSize = true;
            checkTriFelina.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkTriFelina.ForeColor = Color.Black;
            checkTriFelina.Location = new Point(124, 83);
            checkTriFelina.Margin = new Padding(3, 2, 3, 2);
            checkTriFelina.Name = "checkTriFelina";
            checkTriFelina.RightToLeft = RightToLeft.Yes;
            checkTriFelina.Size = new Size(112, 22);
            checkTriFelina.TabIndex = 69;
            checkTriFelina.Text = "Triple Felina";
            checkTriFelina.TextAlign = ContentAlignment.MiddleCenter;
            checkTriFelina.UseVisualStyleBackColor = true;
            // 
            // checkBordetella
            // 
            checkBordetella.AutoSize = true;
            checkBordetella.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkBordetella.ForeColor = Color.Black;
            checkBordetella.Location = new Point(10, 117);
            checkBordetella.Margin = new Padding(3, 2, 3, 2);
            checkBordetella.Name = "checkBordetella";
            checkBordetella.RightToLeft = RightToLeft.Yes;
            checkBordetella.Size = new Size(98, 22);
            checkBordetella.TabIndex = 70;
            checkBordetella.Text = "Bordetella";
            checkBordetella.TextAlign = ContentAlignment.MiddleCenter;
            checkBordetella.UseVisualStyleBackColor = true;
            // 
            // checkLeucemia
            // 
            checkLeucemia.AutoSize = true;
            checkLeucemia.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkLeucemia.ForeColor = Color.Black;
            checkLeucemia.Location = new Point(145, 117);
            checkLeucemia.Margin = new Padding(3, 2, 3, 2);
            checkLeucemia.Name = "checkLeucemia";
            checkLeucemia.RightToLeft = RightToLeft.Yes;
            checkLeucemia.Size = new Size(96, 22);
            checkLeucemia.TabIndex = 71;
            checkLeucemia.Text = "Leucemia";
            checkLeucemia.TextAlign = ContentAlignment.MiddleCenter;
            checkLeucemia.UseVisualStyleBackColor = true;
            // 
            // labelOtros
            // 
            labelOtros.AutoSize = true;
            labelOtros.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelOtros.ForeColor = Color.Black;
            labelOtros.Location = new Point(10, 155);
            labelOtros.Name = "labelOtros";
            labelOtros.Size = new Size(42, 18);
            labelOtros.TabIndex = 72;
            labelOtros.Text = "Otra:";
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox2.Location = new Point(65, 152);
            textBox2.Margin = new Padding(3, 2, 3, 2);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(273, 26);
            textBox2.TabIndex = 73;
            // 
            // panel1
            // 
            panel1.BackColor = Color.WhiteSmoke;
            panel1.Controls.Add(btnMin1);
            panel1.Controls.Add(textBox1);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(dateTimePicker2);
            panel1.Controls.Add(checkGarrapatas);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(txtMedicina);
            panel1.Controls.Add(labelMedi);
            panel1.Controls.Add(dateTimePicker1);
            panel1.Controls.Add(checkParasitos);
            panel1.Controls.Add(labelParasitos);
            panel1.Controls.Add(checkVacuna);
            panel1.Controls.Add(textBox2);
            panel1.Controls.Add(checkRabia);
            panel1.Controls.Add(labelOtros);
            panel1.Controls.Add(checkQuintuple);
            panel1.Controls.Add(checkLeucemia);
            panel1.Controls.Add(checkParvovirus);
            panel1.Controls.Add(checkBordetella);
            panel1.Controls.Add(checkGiardia);
            panel1.Controls.Add(checkTriFelina);
            panel1.Location = new Point(10, 82);
            panel1.Margin = new Padding(3, 2, 3, 2);
            panel1.MaximumSize = new Size(0, 331);
            panel1.MinimumSize = new Size(0, 29);
            panel1.Name = "panel1";
            panel1.Size = new Size(354, 331);
            panel1.TabIndex = 74;
            panel1.Paint += panel1_Paint;
            // 
            // btnMin1
            // 
            btnMin1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnMin1.Cursor = Cursors.Hand;
            btnMin1.Image = (Image)resources.GetObject("btnMin1.Image");
            btnMin1.Location = new Point(325, 0);
            btnMin1.Name = "btnMin1";
            btnMin1.Padding = new Padding(2);
            btnMin1.Size = new Size(29, 27);
            btnMin1.SizeMode = PictureBoxSizeMode.StretchImage;
            btnMin1.TabIndex = 84;
            btnMin1.TabStop = false;
            btnMin1.Click += btnMin1_Click;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox1.Location = new Point(134, 290);
            textBox1.Margin = new Padding(3, 2, 3, 2);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(204, 26);
            textBox1.TabIndex = 83;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(10, 293);
            label1.Name = "label1";
            label1.Size = new Size(107, 18);
            label1.TabIndex = 82;
            label1.Text = "Medicamento:";
            // 
            // dateTimePicker2
            // 
            dateTimePicker2.Location = new Point(248, 258);
            dateTimePicker2.Margin = new Padding(3, 2, 3, 2);
            dateTimePicker2.Name = "dateTimePicker2";
            dateTimePicker2.Size = new Size(89, 23);
            dateTimePicker2.TabIndex = 81;
            // 
            // checkGarrapatas
            // 
            checkGarrapatas.AutoSize = true;
            checkGarrapatas.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkGarrapatas.ForeColor = Color.Black;
            checkGarrapatas.Location = new Point(10, 258);
            checkGarrapatas.Margin = new Padding(3, 2, 3, 2);
            checkGarrapatas.Name = "checkGarrapatas";
            checkGarrapatas.RightToLeft = RightToLeft.Yes;
            checkGarrapatas.Size = new Size(157, 22);
            checkGarrapatas.TabIndex = 80;
            checkGarrapatas.Text = "Control garrapatas";
            checkGarrapatas.TextAlign = ContentAlignment.MiddleCenter;
            checkGarrapatas.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(188, 260);
            label2.Name = "label2";
            label2.Size = new Size(56, 18);
            label2.TabIndex = 79;
            label2.Text = "Fecha:";
            // 
            // txtMedicina
            // 
            txtMedicina.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtMedicina.Location = new Point(124, 221);
            txtMedicina.Margin = new Padding(3, 2, 3, 2);
            txtMedicina.Name = "txtMedicina";
            txtMedicina.Size = new Size(213, 26);
            txtMedicina.TabIndex = 78;
            // 
            // labelMedi
            // 
            labelMedi.AutoSize = true;
            labelMedi.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelMedi.ForeColor = Color.Black;
            labelMedi.Location = new Point(10, 223);
            labelMedi.Name = "labelMedi";
            labelMedi.Size = new Size(107, 18);
            labelMedi.TabIndex = 77;
            labelMedi.Text = "Medicamento:";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(241, 188);
            dateTimePicker1.Margin = new Padding(3, 2, 3, 2);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(97, 23);
            dateTimePicker1.TabIndex = 76;
            // 
            // checkParasitos
            // 
            checkParasitos.AutoSize = true;
            checkParasitos.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkParasitos.ForeColor = Color.Black;
            checkParasitos.Location = new Point(10, 189);
            checkParasitos.Margin = new Padding(3, 2, 3, 2);
            checkParasitos.Name = "checkParasitos";
            checkParasitos.RightToLeft = RightToLeft.Yes;
            checkParasitos.Size = new Size(142, 22);
            checkParasitos.TabIndex = 75;
            checkParasitos.Text = "Desparacitación";
            checkParasitos.TextAlign = ContentAlignment.MiddleCenter;
            checkParasitos.UseVisualStyleBackColor = true;
            // 
            // labelParasitos
            // 
            labelParasitos.AutoSize = true;
            labelParasitos.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelParasitos.ForeColor = Color.Black;
            labelParasitos.Location = new Point(177, 190);
            labelParasitos.Name = "labelParasitos";
            labelParasitos.Size = new Size(56, 18);
            labelParasitos.TabIndex = 74;
            labelParasitos.Text = "Fecha:";
            // 
            // panel2
            // 
            panel2.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel2.AutoScroll = true;
            panel2.BackColor = Color.WhiteSmoke;
            panel2.Controls.Add(btnMin2);
            panel2.Controls.Add(textBox4);
            panel2.Controls.Add(label8);
            panel2.Controls.Add(textBox6);
            panel2.Controls.Add(label7);
            panel2.Controls.Add(txtBoxTenencia);
            panel2.Controls.Add(txtBoxMascotas);
            panel2.Controls.Add(txtBoxDieta);
            panel2.Controls.Add(label6);
            panel2.Controls.Add(txtEnfermedades);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(textBox3);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(checkBox1);
            panel2.Controls.Add(label5);
            panel2.Controls.Add(checkAcceso);
            panel2.Controls.Add(labelTenencia);
            panel2.Location = new Point(384, 82);
            panel2.Margin = new Padding(3, 2, 3, 2);
            panel2.MaximumSize = new Size(0, 331);
            panel2.MinimumSize = new Size(354, 29);
            panel2.Name = "panel2";
            panel2.Size = new Size(354, 331);
            panel2.TabIndex = 84;
            // 
            // btnMin2
            // 
            btnMin2.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnMin2.Cursor = Cursors.Hand;
            btnMin2.Image = (Image)resources.GetObject("btnMin2.Image");
            btnMin2.Location = new Point(325, 0);
            btnMin2.Name = "btnMin2";
            btnMin2.Padding = new Padding(2);
            btnMin2.Size = new Size(29, 27);
            btnMin2.SizeMode = PictureBoxSizeMode.StretchImage;
            btnMin2.TabIndex = 85;
            btnMin2.TabStop = false;
            btnMin2.Click += btnMin2_Click;
            // 
            // textBox4
            // 
            textBox4.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            textBox4.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox4.Location = new Point(10, 294);
            textBox4.Margin = new Padding(3, 2, 3, 2);
            textBox4.Multiline = true;
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(341, 22);
            textBox4.TabIndex = 93;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.Black;
            label8.Location = new Point(10, 273);
            label8.Name = "label8";
            label8.Size = new Size(221, 18);
            label8.TabIndex = 92;
            label8.Text = "Medic. administrados en casa:";
            // 
            // textBox6
            // 
            textBox6.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            textBox6.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox6.Location = new Point(10, 244);
            textBox6.Margin = new Padding(3, 2, 3, 2);
            textBox6.Multiline = true;
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(341, 22);
            textBox6.TabIndex = 91;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.Black;
            label7.Location = new Point(10, 225);
            label7.Name = "label7";
            label7.Size = new Size(164, 18);
            label7.TabIndex = 90;
            label7.Text = "Sintomas observados:";
            // 
            // txtBoxTenencia
            // 
            txtBoxTenencia.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txtBoxTenencia.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtBoxTenencia.Location = new Point(255, 47);
            txtBoxTenencia.Margin = new Padding(3, 2, 3, 2);
            txtBoxTenencia.Name = "txtBoxTenencia";
            txtBoxTenencia.Size = new Size(96, 26);
            txtBoxTenencia.TabIndex = 89;
            // 
            // txtBoxMascotas
            // 
            txtBoxMascotas.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txtBoxMascotas.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtBoxMascotas.Location = new Point(155, 79);
            txtBoxMascotas.Margin = new Padding(3, 2, 3, 2);
            txtBoxMascotas.Name = "txtBoxMascotas";
            txtBoxMascotas.Size = new Size(196, 26);
            txtBoxMascotas.TabIndex = 88;
            // 
            // txtBoxDieta
            // 
            txtBoxDieta.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txtBoxDieta.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtBoxDieta.Location = new Point(155, 108);
            txtBoxDieta.Margin = new Padding(3, 2, 3, 2);
            txtBoxDieta.Name = "txtBoxDieta";
            txtBoxDieta.Size = new Size(196, 26);
            txtBoxDieta.TabIndex = 87;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.Black;
            label6.Location = new Point(10, 110);
            label6.Name = "label6";
            label6.Size = new Size(129, 18);
            label6.TabIndex = 86;
            label6.Text = "Dieta alimenticia:";
            // 
            // txtEnfermedades
            // 
            txtEnfermedades.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txtEnfermedades.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtEnfermedades.Location = new Point(187, 163);
            txtEnfermedades.Margin = new Padding(3, 2, 3, 2);
            txtEnfermedades.Name = "txtEnfermedades";
            txtEnfermedades.Size = new Size(164, 26);
            txtEnfermedades.TabIndex = 85;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Black;
            label4.Location = new Point(10, 165);
            label4.Name = "label4";
            label4.Size = new Size(155, 18);
            label4.TabIndex = 84;
            label4.Text = "Enfermedad anterior:";
            // 
            // textBox3
            // 
            textBox3.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            textBox3.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox3.Location = new Point(84, 194);
            textBox3.Margin = new Padding(3, 2, 3, 2);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(267, 26);
            textBox3.TabIndex = 83;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Black;
            label3.Location = new Point(10, 196);
            label3.Name = "label3";
            label3.Size = new Size(62, 18);
            label3.TabIndex = 82;
            label3.Text = "Hábitat:";
            // 
            // checkBox1
            // 
            checkBox1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            checkBox1.AutoSize = true;
            checkBox1.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkBox1.ForeColor = Color.Black;
            checkBox1.Location = new Point(164, 138);
            checkBox1.Margin = new Padding(3, 2, 3, 2);
            checkBox1.Name = "checkBox1";
            checkBox1.RightToLeft = RightToLeft.Yes;
            checkBox1.Size = new Size(159, 22);
            checkBox1.TabIndex = 80;
            checkBox1.Text = "Contacto/enfermos";
            checkBox1.TextAlign = ContentAlignment.MiddleCenter;
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.Black;
            label5.Location = new Point(10, 84);
            label5.Name = "label5";
            label5.Size = new Size(122, 18);
            label5.TabIndex = 77;
            label5.Text = "Otras mascotas:";
            // 
            // checkAcceso
            // 
            checkAcceso.AutoSize = true;
            checkAcceso.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkAcceso.ForeColor = Color.Black;
            checkAcceso.Location = new Point(10, 138);
            checkAcceso.Margin = new Padding(3, 2, 3, 2);
            checkAcceso.Name = "checkAcceso";
            checkAcceso.RightToLeft = RightToLeft.Yes;
            checkAcceso.Size = new Size(129, 22);
            checkAcceso.TabIndex = 75;
            checkAcceso.Text = "Acceso a calle";
            checkAcceso.TextAlign = ContentAlignment.MiddleCenter;
            checkAcceso.UseVisualStyleBackColor = true;
            // 
            // labelTenencia
            // 
            labelTenencia.AutoSize = true;
            labelTenencia.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelTenencia.ForeColor = Color.Black;
            labelTenencia.Location = new Point(10, 50);
            labelTenencia.Name = "labelTenencia";
            labelTenencia.Size = new Size(218, 18);
            labelTenencia.TabIndex = 72;
            labelTenencia.Text = "Tiempo de posesión mascota:";
            // 
            // panel3
            // 
            panel3.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel3.BackColor = Color.WhiteSmoke;
            panel3.Controls.Add(panel10);
            panel3.Controls.Add(panel9);
            panel3.Controls.Add(panel8);
            panel3.Controls.Add(panel7);
            panel3.Controls.Add(panel6);
            panel3.Controls.Add(panel5);
            panel3.Controls.Add(panel4);
            panel3.Controls.Add(button1);
            panel3.Controls.Add(cbEditar);
            panel3.Controls.Add(btnNewConsulta);
            panel3.Location = new Point(10, 462);
            panel3.Margin = new Padding(3, 2, 3, 2);
            panel3.MinimumSize = new Size(728, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(728, 928);
            panel3.TabIndex = 85;
            // 
            // panel10
            // 
            panel10.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel10.Controls.Add(btnMin10);
            panel10.Controls.Add(label46);
            panel10.Controls.Add(label47);
            panel10.Controls.Add(textBox32);
            panel10.Controls.Add(label45);
            panel10.Controls.Add(textBox31);
            panel10.Controls.Add(checkBox13);
            panel10.Controls.Add(label44);
            panel10.Controls.Add(textBox30);
            panel10.Controls.Add(checkBox12);
            panel10.Controls.Add(label43);
            panel10.Controls.Add(textBox37);
            panel10.Controls.Add(textBox29);
            panel10.Controls.Add(label52);
            panel10.Controls.Add(label42);
            panel10.Controls.Add(textBox38);
            panel10.Controls.Add(textBox28);
            panel10.Controls.Add(label53);
            panel10.Controls.Add(label38);
            panel10.Controls.Add(textBox39);
            panel10.Controls.Add(textBox25);
            panel10.Controls.Add(label54);
            panel10.Controls.Add(label48);
            panel10.Controls.Add(textBox35);
            panel10.Controls.Add(textBox33);
            panel10.Controls.Add(label50);
            panel10.Controls.Add(label49);
            panel10.Controls.Add(textBox36);
            panel10.Controls.Add(textBox34);
            panel10.Controls.Add(label51);
            panel10.Location = new Point(2, 655);
            panel10.MaximumSize = new Size(0, 212);
            panel10.MinimumSize = new Size(0, 30);
            panel10.Name = "panel10";
            panel10.Size = new Size(726, 212);
            panel10.TabIndex = 205;
            // 
            // btnMin10
            // 
            btnMin10.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnMin10.Cursor = Cursors.Hand;
            btnMin10.Image = (Image)resources.GetObject("btnMin10.Image");
            btnMin10.Location = new Point(697, 0);
            btnMin10.Name = "btnMin10";
            btnMin10.Padding = new Padding(2);
            btnMin10.Size = new Size(29, 27);
            btnMin10.SizeMode = PictureBoxSizeMode.StretchImage;
            btnMin10.TabIndex = 207;
            btnMin10.TabStop = false;
            btnMin10.Click += btnMin10_Click;
            // 
            // label46
            // 
            label46.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            label46.Font = new Font("Microsoft Sans Serif", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label46.ForeColor = Color.Black;
            label46.Location = new Point(11, 0);
            label46.Name = "label46";
            label46.Size = new Size(257, 24);
            label46.TabIndex = 166;
            label46.Text = "Sistema Nervioso:";
            // 
            // label47
            // 
            label47.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label47.AutoSize = true;
            label47.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label47.ForeColor = Color.Black;
            label47.Location = new Point(11, 61);
            label47.Name = "label47";
            label47.Size = new Size(113, 18);
            label47.TabIndex = 167;
            label47.Text = "Incoordinación:";
            // 
            // textBox32
            // 
            textBox32.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox32.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox32.Location = new Point(157, 60);
            textBox32.Margin = new Padding(3, 2, 3, 2);
            textBox32.Name = "textBox32";
            textBox32.Size = new Size(150, 26);
            textBox32.TabIndex = 168;
            // 
            // label45
            // 
            label45.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            label45.AutoSize = true;
            label45.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label45.ForeColor = Color.Black;
            label45.Location = new Point(311, 62);
            label45.Name = "label45";
            label45.Size = new Size(79, 18);
            label45.TabIndex = 169;
            label45.Text = "Dismetría:";
            // 
            // textBox31
            // 
            textBox31.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            textBox31.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox31.Location = new Point(396, 58);
            textBox31.Margin = new Padding(3, 2, 3, 2);
            textBox31.Name = "textBox31";
            textBox31.Size = new Size(320, 26);
            textBox31.TabIndex = 170;
            // 
            // checkBox13
            // 
            checkBox13.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            checkBox13.AutoSize = true;
            checkBox13.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkBox13.ForeColor = Color.Black;
            checkBox13.Location = new Point(11, 90);
            checkBox13.Margin = new Padding(3, 2, 3, 2);
            checkBox13.Name = "checkBox13";
            checkBox13.RightToLeft = RightToLeft.Yes;
            checkBox13.Size = new Size(197, 22);
            checkBox13.TabIndex = 171;
            checkBox13.Text = "Golpe previos en cráneo";
            checkBox13.TextAlign = ContentAlignment.MiddleCenter;
            checkBox13.UseVisualStyleBackColor = true;
            // 
            // label44
            // 
            label44.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label44.AutoSize = true;
            label44.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label44.ForeColor = Color.Black;
            label44.Location = new Point(487, 91);
            label44.Name = "label44";
            label44.Size = new Size(44, 18);
            label44.TabIndex = 172;
            label44.Text = "Ojos:";
            // 
            // textBox30
            // 
            textBox30.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox30.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox30.Location = new Point(554, 88);
            textBox30.Margin = new Padding(3, 2, 3, 2);
            textBox30.Name = "textBox30";
            textBox30.Size = new Size(162, 26);
            textBox30.TabIndex = 173;
            // 
            // checkBox12
            // 
            checkBox12.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            checkBox12.AutoSize = true;
            checkBox12.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkBox12.ForeColor = Color.Black;
            checkBox12.Location = new Point(239, 90);
            checkBox12.Margin = new Padding(3, 2, 3, 2);
            checkBox12.Name = "checkBox12";
            checkBox12.RightToLeft = RightToLeft.Yes;
            checkBox12.Size = new Size(174, 22);
            checkBox12.TabIndex = 174;
            checkBox12.Text = "Responde al llamado";
            checkBox12.TextAlign = ContentAlignment.MiddleCenter;
            checkBox12.UseVisualStyleBackColor = true;
            // 
            // label43
            // 
            label43.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label43.AutoSize = true;
            label43.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label43.ForeColor = Color.Black;
            label43.Location = new Point(11, 154);
            label43.Name = "label43";
            label43.Size = new Size(53, 18);
            label43.TabIndex = 175;
            label43.Text = "Oídos:";
            // 
            // textBox37
            // 
            textBox37.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            textBox37.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox37.Location = new Point(541, 180);
            textBox37.Margin = new Padding(3, 2, 3, 2);
            textBox37.Name = "textBox37";
            textBox37.Size = new Size(176, 26);
            textBox37.TabIndex = 194;
            // 
            // textBox29
            // 
            textBox29.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox29.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox29.Location = new Point(73, 150);
            textBox29.Margin = new Padding(3, 2, 3, 2);
            textBox29.Name = "textBox29";
            textBox29.Size = new Size(86, 26);
            textBox29.TabIndex = 176;
            // 
            // label52
            // 
            label52.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            label52.AutoSize = true;
            label52.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label52.ForeColor = Color.Black;
            label52.Location = new Point(457, 184);
            label52.Name = "label52";
            label52.Size = new Size(75, 18);
            label52.TabIndex = 193;
            label52.Text = "Afectado:";
            // 
            // label42
            // 
            label42.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            label42.AutoSize = true;
            label42.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label42.ForeColor = Color.Black;
            label42.Location = new Point(161, 154);
            label42.Name = "label42";
            label42.Size = new Size(75, 18);
            label42.TabIndex = 177;
            label42.Text = "Se rasca:";
            // 
            // textBox38
            // 
            textBox38.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox38.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox38.Location = new Point(423, 181);
            textBox38.Margin = new Padding(3, 2, 3, 2);
            textBox38.Name = "textBox38";
            textBox38.Size = new Size(51, 26);
            textBox38.TabIndex = 192;
            // 
            // textBox28
            // 
            textBox28.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            textBox28.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox28.Location = new Point(247, 150);
            textBox28.Margin = new Padding(3, 2, 3, 2);
            textBox28.Name = "textBox28";
            textBox28.Size = new Size(88, 26);
            textBox28.TabIndex = 178;
            // 
            // label53
            // 
            label53.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label53.AutoSize = true;
            label53.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label53.ForeColor = Color.Black;
            label53.Location = new Point(302, 184);
            label53.Name = "label53";
            label53.Size = new Size(115, 18);
            label53.TabIndex = 191;
            label53.Text = "Descarga/Tipo:";
            // 
            // label38
            // 
            label38.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            label38.AutoSize = true;
            label38.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label38.ForeColor = Color.Black;
            label38.Location = new Point(337, 154);
            label38.Name = "label38";
            label38.Size = new Size(67, 18);
            label38.TabIndex = 179;
            label38.Text = "Mal olor:";
            // 
            // textBox39
            // 
            textBox39.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            textBox39.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox39.Location = new Point(113, 181);
            textBox39.Margin = new Padding(3, 2, 3, 2);
            textBox39.Name = "textBox39";
            textBox39.Size = new Size(178, 26);
            textBox39.TabIndex = 190;
            // 
            // textBox25
            // 
            textBox25.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            textBox25.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox25.Location = new Point(412, 150);
            textBox25.Margin = new Padding(3, 2, 3, 2);
            textBox25.Name = "textBox25";
            textBox25.Size = new Size(112, 26);
            textBox25.TabIndex = 180;
            // 
            // label54
            // 
            label54.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label54.AutoSize = true;
            label54.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label54.ForeColor = Color.Black;
            label54.Location = new Point(11, 184);
            label54.Name = "label54";
            label54.Size = new Size(79, 18);
            label54.TabIndex = 189;
            label54.Text = "Parásitos:";
            // 
            // label48
            // 
            label48.AutoSize = true;
            label48.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label48.ForeColor = Color.Black;
            label48.Location = new Point(11, 30);
            label48.Name = "label48";
            label48.Size = new Size(129, 18);
            label48.TabIndex = 181;
            label48.Text = "Comportamiento:";
            // 
            // textBox35
            // 
            textBox35.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            textBox35.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox35.Location = new Point(396, 120);
            textBox35.Margin = new Padding(3, 2, 3, 2);
            textBox35.Name = "textBox35";
            textBox35.Size = new Size(320, 26);
            textBox35.TabIndex = 188;
            // 
            // textBox33
            // 
            textBox33.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox33.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox33.Location = new Point(157, 30);
            textBox33.Margin = new Padding(3, 2, 3, 2);
            textBox33.Name = "textBox33";
            textBox33.Size = new Size(559, 26);
            textBox33.TabIndex = 182;
            // 
            // label50
            // 
            label50.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            label50.AutoSize = true;
            label50.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label50.ForeColor = Color.Black;
            label50.Location = new Point(314, 121);
            label50.Name = "label50";
            label50.Size = new Size(73, 18);
            label50.TabIndex = 187;
            label50.Text = "Ceguera:";
            // 
            // label49
            // 
            label49.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            label49.AutoSize = true;
            label49.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label49.ForeColor = Color.Black;
            label49.Location = new Point(527, 154);
            label49.Name = "label49";
            label49.Size = new Size(72, 18);
            label49.TabIndex = 183;
            label49.Text = "Escucha:";
            // 
            // textBox36
            // 
            textBox36.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox36.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox36.Location = new Point(113, 119);
            textBox36.Margin = new Padding(3, 2, 3, 2);
            textBox36.Name = "textBox36";
            textBox36.Size = new Size(194, 26);
            textBox36.TabIndex = 186;
            // 
            // textBox34
            // 
            textBox34.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            textBox34.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox34.Location = new Point(602, 150);
            textBox34.Margin = new Padding(3, 2, 3, 2);
            textBox34.Name = "textBox34";
            textBox34.Size = new Size(114, 26);
            textBox34.TabIndex = 184;
            // 
            // label51
            // 
            label51.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label51.AutoSize = true;
            label51.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label51.ForeColor = Color.Black;
            label51.Location = new Point(11, 124);
            label51.Name = "label51";
            label51.Size = new Size(83, 18);
            label51.TabIndex = 185;
            label51.Text = "Secreción:";
            // 
            // panel9
            // 
            panel9.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel9.Controls.Add(btnMin9);
            panel9.Controls.Add(textBox26);
            panel9.Controls.Add(label41);
            panel9.Controls.Add(label40);
            panel9.Controls.Add(textBox27);
            panel9.Controls.Add(label39);
            panel9.Controls.Add(checkBox7);
            panel9.Controls.Add(label37);
            panel9.Controls.Add(textBox24);
            panel9.Controls.Add(checkBox6);
            panel9.Controls.Add(label35);
            panel9.Controls.Add(textBox22);
            panel9.Controls.Add(label32);
            panel9.Controls.Add(textBox20);
            panel9.Controls.Add(label36);
            panel9.Controls.Add(textBox23);
            panel9.Location = new Point(0, 526);
            panel9.MaximumSize = new Size(0, 128);
            panel9.MinimumSize = new Size(0, 35);
            panel9.Name = "panel9";
            panel9.Size = new Size(728, 128);
            panel9.TabIndex = 204;
            // 
            // btnMin9
            // 
            btnMin9.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnMin9.Cursor = Cursors.Hand;
            btnMin9.Image = (Image)resources.GetObject("btnMin9.Image");
            btnMin9.Location = new Point(699, 0);
            btnMin9.Name = "btnMin9";
            btnMin9.Padding = new Padding(2);
            btnMin9.Size = new Size(29, 27);
            btnMin9.SizeMode = PictureBoxSizeMode.StretchImage;
            btnMin9.TabIndex = 208;
            btnMin9.TabStop = false;
            btnMin9.Click += btnMin9_Click;
            // 
            // textBox26
            // 
            textBox26.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            textBox26.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox26.Location = new Point(374, 37);
            textBox26.Margin = new Padding(3, 2, 3, 2);
            textBox26.Name = "textBox26";
            textBox26.Size = new Size(346, 26);
            textBox26.TabIndex = 151;
            // 
            // label41
            // 
            label41.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label41.AutoSize = true;
            label41.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label41.ForeColor = Color.Black;
            label41.Location = new Point(13, 39);
            label41.Name = "label41";
            label41.Size = new Size(50, 18);
            label41.TabIndex = 148;
            label41.Text = "Orina:";
            // 
            // label40
            // 
            label40.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            label40.Font = new Font("Microsoft Sans Serif", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label40.ForeColor = Color.Black;
            label40.Location = new Point(13, 10);
            label40.Name = "label40";
            label40.Size = new Size(265, 29);
            label40.TabIndex = 147;
            label40.Text = "Sistema Urogenital:";
            // 
            // textBox27
            // 
            textBox27.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox27.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox27.Location = new Point(77, 36);
            textBox27.Margin = new Padding(3, 2, 3, 2);
            textBox27.Name = "textBox27";
            textBox27.Size = new Size(176, 26);
            textBox27.TabIndex = 149;
            // 
            // label39
            // 
            label39.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            label39.AutoSize = true;
            label39.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label39.ForeColor = Color.Black;
            label39.Location = new Point(251, 39);
            label39.Name = "label39";
            label39.Size = new Size(108, 18);
            label39.TabIndex = 150;
            label39.Text = "Castrado/Ovh:";
            // 
            // checkBox7
            // 
            checkBox7.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            checkBox7.AutoSize = true;
            checkBox7.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkBox7.ForeColor = Color.Black;
            checkBox7.Location = new Point(13, 70);
            checkBox7.Margin = new Padding(3, 2, 3, 2);
            checkBox7.Name = "checkBox7";
            checkBox7.RightToLeft = RightToLeft.Yes;
            checkBox7.Size = new Size(198, 22);
            checkBox7.TabIndex = 154;
            checkBox7.Text = "Se ha cruzado con razas";
            checkBox7.TextAlign = ContentAlignment.MiddleCenter;
            checkBox7.UseVisualStyleBackColor = true;
            // 
            // label37
            // 
            label37.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label37.AutoSize = true;
            label37.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label37.ForeColor = Color.Black;
            label37.Location = new Point(433, 70);
            label37.Name = "label37";
            label37.Size = new Size(107, 18);
            label37.TabIndex = 155;
            label37.Text = "Pseudociesis:";
            // 
            // textBox24
            // 
            textBox24.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox24.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox24.Location = new Point(556, 67);
            textBox24.Margin = new Padding(3, 2, 3, 2);
            textBox24.Name = "textBox24";
            textBox24.Size = new Size(164, 26);
            textBox24.TabIndex = 156;
            // 
            // checkBox6
            // 
            checkBox6.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            checkBox6.AutoSize = true;
            checkBox6.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkBox6.ForeColor = Color.Black;
            checkBox6.Location = new Point(241, 68);
            checkBox6.Margin = new Padding(3, 2, 3, 2);
            checkBox6.Name = "checkBox6";
            checkBox6.RightToLeft = RightToLeft.Yes;
            checkBox6.Size = new Size(163, 22);
            checkBox6.TabIndex = 159;
            checkBox6.Text = "Ha estado gestante";
            checkBox6.TextAlign = ContentAlignment.MiddleCenter;
            checkBox6.UseVisualStyleBackColor = true;
            // 
            // label35
            // 
            label35.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label35.AutoSize = true;
            label35.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label35.ForeColor = Color.Black;
            label35.Location = new Point(13, 100);
            label35.Name = "label35";
            label35.Size = new Size(89, 18);
            label35.TabIndex = 160;
            label35.Text = "Último celo:";
            // 
            // textBox22
            // 
            textBox22.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            textBox22.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox22.Location = new Point(115, 96);
            textBox22.Margin = new Padding(3, 2, 3, 2);
            textBox22.Name = "textBox22";
            textBox22.Size = new Size(98, 26);
            textBox22.TabIndex = 161;
            // 
            // label32
            // 
            label32.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label32.AutoSize = true;
            label32.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label32.ForeColor = Color.Black;
            label32.Location = new Point(220, 100);
            label32.Name = "label32";
            label32.Size = new Size(92, 18);
            label32.TabIndex = 162;
            label32.Text = "Último parto";
            // 
            // textBox20
            // 
            textBox20.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            textBox20.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox20.Location = new Point(322, 98);
            textBox20.Margin = new Padding(3, 2, 3, 2);
            textBox20.Name = "textBox20";
            textBox20.Size = new Size(103, 26);
            textBox20.TabIndex = 163;
            // 
            // label36
            // 
            label36.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label36.AutoSize = true;
            label36.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label36.ForeColor = Color.Black;
            label36.Location = new Point(433, 100);
            label36.Name = "label36";
            label36.Size = new Size(202, 18);
            label36.TabIndex = 164;
            label36.Text = "Descarga prepucial/vaginal:";
            // 
            // textBox23
            // 
            textBox23.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox23.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox23.Location = new Point(648, 96);
            textBox23.Margin = new Padding(3, 2, 3, 2);
            textBox23.Name = "textBox23";
            textBox23.Size = new Size(72, 26);
            textBox23.TabIndex = 165;
            // 
            // panel8
            // 
            panel8.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel8.Controls.Add(btnMin8);
            panel8.Controls.Add(label33);
            panel8.Controls.Add(label34);
            panel8.Controls.Add(textBox21);
            panel8.Controls.Add(label31);
            panel8.Controls.Add(textBox19);
            panel8.Controls.Add(label30);
            panel8.Controls.Add(textBox18);
            panel8.Location = new Point(0, 430);
            panel8.MaximumSize = new Size(0, 100);
            panel8.MinimumSize = new Size(0, 35);
            panel8.Name = "panel8";
            panel8.Size = new Size(728, 100);
            panel8.TabIndex = 203;
            // 
            // btnMin8
            // 
            btnMin8.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnMin8.Cursor = Cursors.Hand;
            btnMin8.Image = (Image)resources.GetObject("btnMin8.Image");
            btnMin8.Location = new Point(699, 3);
            btnMin8.Name = "btnMin8";
            btnMin8.Padding = new Padding(2);
            btnMin8.Size = new Size(29, 27);
            btnMin8.SizeMode = PictureBoxSizeMode.StretchImage;
            btnMin8.TabIndex = 209;
            btnMin8.TabStop = false;
            btnMin8.Click += btnMin8_Click;
            // 
            // label33
            // 
            label33.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            label33.Font = new Font("Microsoft Sans Serif", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label33.ForeColor = Color.Black;
            label33.Location = new Point(11, 6);
            label33.Name = "label33";
            label33.Size = new Size(281, 27);
            label33.TabIndex = 138;
            label33.Text = "Sistema Cardiovascular:";
            // 
            // label34
            // 
            label34.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label34.AutoSize = true;
            label34.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label34.ForeColor = Color.Black;
            label34.Location = new Point(11, 37);
            label34.Name = "label34";
            label34.Size = new Size(150, 18);
            label34.TabIndex = 139;
            label34.Text = "Se fátiga facilmente:";
            // 
            // textBox21
            // 
            textBox21.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox21.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox21.Location = new Point(199, 35);
            textBox21.Margin = new Padding(3, 2, 3, 2);
            textBox21.Name = "textBox21";
            textBox21.Size = new Size(519, 26);
            textBox21.TabIndex = 140;
            // 
            // label31
            // 
            label31.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label31.AutoSize = true;
            label31.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label31.ForeColor = Color.Black;
            label31.Location = new Point(11, 67);
            label31.Name = "label31";
            label31.Size = new Size(73, 18);
            label31.TabIndex = 143;
            label31.Text = "Clanosis:";
            // 
            // textBox19
            // 
            textBox19.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox19.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox19.Location = new Point(94, 65);
            textBox19.Margin = new Padding(3, 2, 3, 2);
            textBox19.Name = "textBox19";
            textBox19.Size = new Size(157, 26);
            textBox19.TabIndex = 144;
            // 
            // label30
            // 
            label30.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            label30.AutoSize = true;
            label30.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label30.ForeColor = Color.Black;
            label30.Location = new Point(256, 67);
            label30.Name = "label30";
            label30.Size = new Size(99, 18);
            label30.TabIndex = 145;
            label30.Text = "Tos nocturna:";
            // 
            // textBox18
            // 
            textBox18.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            textBox18.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox18.Location = new Point(372, 65);
            textBox18.Margin = new Padding(3, 2, 3, 2);
            textBox18.Name = "textBox18";
            textBox18.Size = new Size(346, 26);
            textBox18.TabIndex = 146;
            // 
            // panel7
            // 
            panel7.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel7.Controls.Add(btnMin7);
            panel7.Controls.Add(label27);
            panel7.Controls.Add(label28);
            panel7.Controls.Add(textBox16);
            panel7.Controls.Add(label26);
            panel7.Controls.Add(textBox15);
            panel7.Controls.Add(label25);
            panel7.Controls.Add(textBox14);
            panel7.Controls.Add(label24);
            panel7.Controls.Add(textBox13);
            panel7.Controls.Add(label29);
            panel7.Controls.Add(textBox17);
            panel7.Location = new Point(0, 333);
            panel7.MaximumSize = new Size(0, 100);
            panel7.MinimumSize = new Size(0, 35);
            panel7.Name = "panel7";
            panel7.Size = new Size(728, 100);
            panel7.TabIndex = 202;
            panel7.Paint += panel7_Paint;
            // 
            // btnMin7
            // 
            btnMin7.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnMin7.Cursor = Cursors.Hand;
            btnMin7.Image = (Image)resources.GetObject("btnMin7.Image");
            btnMin7.Location = new Point(699, 0);
            btnMin7.Name = "btnMin7";
            btnMin7.Padding = new Padding(2);
            btnMin7.Size = new Size(29, 27);
            btnMin7.SizeMode = PictureBoxSizeMode.StretchImage;
            btnMin7.TabIndex = 138;
            btnMin7.TabStop = false;
            btnMin7.Click += btnMin7_Click;
            // 
            // label27
            // 
            label27.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            label27.Font = new Font("Microsoft Sans Serif", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label27.ForeColor = Color.Black;
            label27.Location = new Point(8, 2);
            label27.Name = "label27";
            label27.Size = new Size(245, 33);
            label27.TabIndex = 127;
            label27.Text = "Sistema Respiratorio:";
            // 
            // label28
            // 
            label28.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label28.AutoSize = true;
            label28.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label28.ForeColor = Color.Black;
            label28.Location = new Point(8, 39);
            label28.Name = "label28";
            label28.Size = new Size(36, 18);
            label28.TabIndex = 128;
            label28.Text = "Tos:";
            // 
            // textBox16
            // 
            textBox16.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            textBox16.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox16.Location = new Point(55, 37);
            textBox16.Margin = new Padding(3, 2, 3, 2);
            textBox16.Name = "textBox16";
            textBox16.Size = new Size(200, 26);
            textBox16.TabIndex = 129;
            // 
            // label26
            // 
            label26.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label26.AutoSize = true;
            label26.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label26.ForeColor = Color.Black;
            label26.Location = new Point(288, 39);
            label26.Name = "label26";
            label26.Size = new Size(42, 18);
            label26.TabIndex = 130;
            label26.Text = "Tipo:";
            // 
            // textBox15
            // 
            textBox15.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox15.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox15.Location = new Point(339, 37);
            textBox15.Margin = new Padding(3, 2, 3, 2);
            textBox15.Name = "textBox15";
            textBox15.Size = new Size(132, 26);
            textBox15.TabIndex = 131;
            // 
            // label25
            // 
            label25.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label25.AutoSize = true;
            label25.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label25.ForeColor = Color.Black;
            label25.Location = new Point(8, 69);
            label25.Name = "label25";
            label25.Size = new Size(91, 18);
            label25.TabIndex = 132;
            label25.Text = "Estornudos:";
            // 
            // textBox14
            // 
            textBox14.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            textBox14.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox14.Location = new Point(110, 66);
            textBox14.Margin = new Padding(3, 2, 3, 2);
            textBox14.Name = "textBox14";
            textBox14.Size = new Size(305, 26);
            textBox14.TabIndex = 133;
            textBox14.TextChanged += textBox14_TextChanged;
            // 
            // label24
            // 
            label24.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label24.AutoSize = true;
            label24.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label24.ForeColor = Color.Black;
            label24.Location = new Point(428, 68);
            label24.Name = "label24";
            label24.Size = new Size(122, 18);
            label24.TabIndex = 134;
            label24.Text = "Descarga nasal:";
            // 
            // textBox13
            // 
            textBox13.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox13.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox13.Location = new Point(563, 66);
            textBox13.Margin = new Padding(3, 2, 3, 2);
            textBox13.Name = "textBox13";
            textBox13.Size = new Size(152, 26);
            textBox13.TabIndex = 135;
            // 
            // label29
            // 
            label29.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            label29.AutoSize = true;
            label29.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label29.ForeColor = Color.Black;
            label29.Location = new Point(495, 39);
            label29.Name = "label29";
            label29.Size = new Size(62, 18);
            label29.TabIndex = 136;
            label29.Text = "Disnea:";
            // 
            // textBox17
            // 
            textBox17.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            textBox17.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox17.Location = new Point(563, 37);
            textBox17.Margin = new Padding(3, 2, 3, 2);
            textBox17.Name = "textBox17";
            textBox17.Size = new Size(152, 26);
            textBox17.TabIndex = 137;
            textBox17.TextChanged += textBox17_TextChanged;
            // 
            // panel6
            // 
            panel6.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel6.Controls.Add(btnMin6);
            panel6.Controls.Add(label19);
            panel6.Controls.Add(label20);
            panel6.Controls.Add(textBox9);
            panel6.Controls.Add(label16);
            panel6.Controls.Add(textBox8);
            panel6.Controls.Add(label14);
            panel6.Controls.Add(textBox5);
            panel6.Controls.Add(checkBox2);
            panel6.Controls.Add(label15);
            panel6.Controls.Add(textBox7);
            panel6.Controls.Add(label22);
            panel6.Controls.Add(textBox11);
            panel6.Controls.Add(checkBox11);
            panel6.Controls.Add(label21);
            panel6.Controls.Add(textBox10);
            panel6.Controls.Add(label23);
            panel6.Controls.Add(textBox12);
            panel6.Controls.Add(checkBox3);
            panel6.Controls.Add(checkBox4);
            panel6.Controls.Add(checkBox5);
            panel6.Location = new Point(0, 172);
            panel6.MaximumSize = new Size(0, 166);
            panel6.MinimumSize = new Size(0, 30);
            panel6.Name = "panel6";
            panel6.Size = new Size(728, 166);
            panel6.TabIndex = 201;
            // 
            // btnMin6
            // 
            btnMin6.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnMin6.Cursor = Cursors.Hand;
            btnMin6.Image = (Image)resources.GetObject("btnMin6.Image");
            btnMin6.Location = new Point(699, 1);
            btnMin6.Name = "btnMin6";
            btnMin6.Padding = new Padding(2);
            btnMin6.Size = new Size(29, 27);
            btnMin6.SizeMode = PictureBoxSizeMode.StretchImage;
            btnMin6.TabIndex = 105;
            btnMin6.TabStop = false;
            btnMin6.Click += btnMin6_Click;
            // 
            // label19
            // 
            label19.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            label19.Font = new Font("Microsoft Sans Serif", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label19.ForeColor = Color.Black;
            label19.Location = new Point(3, 0);
            label19.Name = "label19";
            label19.Size = new Size(265, 29);
            label19.TabIndex = 105;
            label19.Text = "Sistema Digestivo:";
            // 
            // label20
            // 
            label20.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label20.AutoSize = true;
            label20.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label20.ForeColor = Color.Black;
            label20.Location = new Point(3, 34);
            label20.Name = "label20";
            label20.Size = new Size(62, 18);
            label20.TabIndex = 106;
            label20.Text = "Apetito:";
            // 
            // textBox9
            // 
            textBox9.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox9.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox9.Location = new Point(86, 33);
            textBox9.Margin = new Padding(3, 2, 3, 2);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(130, 26);
            textBox9.TabIndex = 107;
            // 
            // label16
            // 
            label16.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            label16.AutoSize = true;
            label16.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label16.ForeColor = Color.Black;
            label16.Location = new Point(221, 35);
            label16.Name = "label16";
            label16.Size = new Size(123, 18);
            label16.TabIndex = 108;
            label16.Text = "Ingesta de agua:";
            // 
            // textBox8
            // 
            textBox8.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            textBox8.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox8.Location = new Point(364, 33);
            textBox8.Margin = new Padding(3, 2, 3, 2);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(346, 26);
            textBox8.TabIndex = 109;
            // 
            // label14
            // 
            label14.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label14.AutoSize = true;
            label14.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label14.ForeColor = Color.Black;
            label14.Location = new Point(93, 67);
            label14.Name = "label14";
            label14.Size = new Size(90, 18);
            label14.TabIndex = 112;
            label14.Text = "Frecuencia:";
            // 
            // textBox5
            // 
            textBox5.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox5.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox5.Location = new Point(191, 63);
            textBox5.Margin = new Padding(3, 2, 3, 2);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(70, 26);
            textBox5.TabIndex = 113;
            // 
            // checkBox2
            // 
            checkBox2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            checkBox2.AutoSize = true;
            checkBox2.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkBox2.ForeColor = Color.Black;
            checkBox2.Location = new Point(3, 66);
            checkBox2.Margin = new Padding(3, 2, 3, 2);
            checkBox2.Name = "checkBox2";
            checkBox2.RightToLeft = RightToLeft.Yes;
            checkBox2.Size = new Size(76, 22);
            checkBox2.TabIndex = 114;
            checkBox2.Text = "Vomito";
            checkBox2.TextAlign = ContentAlignment.MiddleCenter;
            checkBox2.UseVisualStyleBackColor = true;
            // 
            // label15
            // 
            label15.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            label15.AutoSize = true;
            label15.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label15.ForeColor = Color.Black;
            label15.Location = new Point(280, 63);
            label15.Name = "label15";
            label15.Size = new Size(70, 18);
            label15.TabIndex = 115;
            label15.Text = "Aspecto:";
            // 
            // textBox7
            // 
            textBox7.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            textBox7.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox7.Location = new Point(364, 62);
            textBox7.Margin = new Padding(3, 2, 3, 2);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(346, 26);
            textBox7.TabIndex = 116;
            // 
            // label22
            // 
            label22.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label22.AutoSize = true;
            label22.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label22.ForeColor = Color.Black;
            label22.Location = new Point(93, 99);
            label22.Name = "label22";
            label22.Size = new Size(90, 18);
            label22.TabIndex = 117;
            label22.Text = "Frecuencia:";
            // 
            // textBox11
            // 
            textBox11.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            textBox11.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox11.Location = new Point(191, 96);
            textBox11.Margin = new Padding(3, 2, 3, 2);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(70, 26);
            textBox11.TabIndex = 118;
            // 
            // checkBox11
            // 
            checkBox11.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            checkBox11.AutoSize = true;
            checkBox11.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkBox11.ForeColor = Color.Black;
            checkBox11.Location = new Point(3, 97);
            checkBox11.Margin = new Padding(3, 2, 3, 2);
            checkBox11.Name = "checkBox11";
            checkBox11.RightToLeft = RightToLeft.Yes;
            checkBox11.Size = new Size(78, 22);
            checkBox11.TabIndex = 119;
            checkBox11.Text = "Defeca";
            checkBox11.TextAlign = ContentAlignment.MiddleCenter;
            checkBox11.UseVisualStyleBackColor = true;
            // 
            // label21
            // 
            label21.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label21.AutoSize = true;
            label21.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label21.ForeColor = Color.Black;
            label21.Location = new Point(274, 97);
            label21.Name = "label21";
            label21.Size = new Size(50, 18);
            label21.TabIndex = 120;
            label21.Text = "Color:";
            // 
            // textBox10
            // 
            textBox10.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            textBox10.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox10.Location = new Point(334, 93);
            textBox10.Margin = new Padding(3, 2, 3, 2);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(132, 26);
            textBox10.TabIndex = 121;
            // 
            // label23
            // 
            label23.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label23.AutoSize = true;
            label23.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label23.ForeColor = Color.Black;
            label23.Location = new Point(479, 96);
            label23.Name = "label23";
            label23.Size = new Size(70, 18);
            label23.TabIndex = 122;
            label23.Text = "Aspecto:";
            // 
            // textBox12
            // 
            textBox12.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox12.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox12.Location = new Point(558, 93);
            textBox12.Margin = new Padding(3, 2, 3, 2);
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(152, 26);
            textBox12.TabIndex = 123;
            // 
            // checkBox3
            // 
            checkBox3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            checkBox3.AutoSize = true;
            checkBox3.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkBox3.ForeColor = Color.Black;
            checkBox3.Location = new Point(3, 134);
            checkBox3.Margin = new Padding(3, 2, 3, 2);
            checkBox3.Name = "checkBox3";
            checkBox3.RightToLeft = RightToLeft.Yes;
            checkBox3.Size = new Size(123, 22);
            checkBox3.TabIndex = 124;
            checkBox3.Text = "Estreñimiento";
            checkBox3.TextAlign = ContentAlignment.MiddleCenter;
            checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            checkBox4.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            checkBox4.AutoSize = true;
            checkBox4.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkBox4.ForeColor = Color.Black;
            checkBox4.Location = new Point(159, 134);
            checkBox4.Margin = new Padding(3, 2, 3, 2);
            checkBox4.Name = "checkBox4";
            checkBox4.RightToLeft = RightToLeft.Yes;
            checkBox4.Size = new Size(102, 22);
            checkBox4.TabIndex = 125;
            checkBox4.Text = "Flatulencia";
            checkBox4.TextAlign = ContentAlignment.MiddleCenter;
            checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            checkBox5.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            checkBox5.AutoSize = true;
            checkBox5.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkBox5.ForeColor = Color.Black;
            checkBox5.Location = new Point(305, 134);
            checkBox5.Margin = new Padding(3, 2, 3, 2);
            checkBox5.Name = "checkBox5";
            checkBox5.RightToLeft = RightToLeft.Yes;
            checkBox5.Size = new Size(97, 22);
            checkBox5.TabIndex = 126;
            checkBox5.Text = "Deglución";
            checkBox5.TextAlign = ContentAlignment.MiddleCenter;
            checkBox5.UseVisualStyleBackColor = true;
            // 
            // panel5
            // 
            panel5.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel5.Controls.Add(btnMin5);
            panel5.Controls.Add(label17);
            panel5.Controls.Add(label18);
            panel5.Controls.Add(txtBoxMovimiento);
            panel5.Location = new Point(0, 99);
            panel5.MaximumSize = new Size(0, 67);
            panel5.MinimumSize = new Size(0, 33);
            panel5.Name = "panel5";
            panel5.Size = new Size(728, 67);
            panel5.TabIndex = 200;
            // 
            // btnMin5
            // 
            btnMin5.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnMin5.Cursor = Cursors.Hand;
            btnMin5.Image = (Image)resources.GetObject("btnMin5.Image");
            btnMin5.Location = new Point(699, 0);
            btnMin5.Name = "btnMin5";
            btnMin5.Padding = new Padding(2);
            btnMin5.Size = new Size(29, 27);
            btnMin5.SizeMode = PictureBoxSizeMode.StretchImage;
            btnMin5.TabIndex = 102;
            btnMin5.TabStop = false;
            btnMin5.Click += btnMin5_Click;
            // 
            // label17
            // 
            label17.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            label17.Font = new Font("Microsoft Sans Serif", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label17.ForeColor = Color.Black;
            label17.Location = new Point(9, 0);
            label17.Name = "label17";
            label17.Size = new Size(377, 25);
            label17.TabIndex = 102;
            label17.Text = "Sistema Musculo Esqueletico:";
            // 
            // label18
            // 
            label18.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label18.AutoSize = true;
            label18.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label18.ForeColor = Color.Black;
            label18.Location = new Point(9, 35);
            label18.Name = "label18";
            label18.Size = new Size(92, 18);
            label18.TabIndex = 103;
            label18.Text = "Movimiento:";
            // 
            // txtBoxMovimiento
            // 
            txtBoxMovimiento.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txtBoxMovimiento.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtBoxMovimiento.Location = new Point(111, 33);
            txtBoxMovimiento.Margin = new Padding(3, 2, 3, 2);
            txtBoxMovimiento.Name = "txtBoxMovimiento";
            txtBoxMovimiento.Size = new Size(605, 26);
            txtBoxMovimiento.TabIndex = 104;
            // 
            // panel4
            // 
            panel4.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel4.Controls.Add(btnMin4);
            panel4.Controls.Add(txtBoxLesiones);
            panel4.Controls.Add(label10);
            panel4.Controls.Add(label9);
            panel4.Controls.Add(txtboxAspecto);
            panel4.Controls.Add(label11);
            panel4.Controls.Add(label12);
            panel4.Controls.Add(txtBoxAlopecia);
            panel4.Controls.Add(label13);
            panel4.Controls.Add(txtBoxParasitos);
            panel4.Location = new Point(2, 3);
            panel4.MaximumSize = new Size(0, 100);
            panel4.MinimumSize = new Size(0, 35);
            panel4.Name = "panel4";
            panel4.Size = new Size(723, 100);
            panel4.TabIndex = 199;
            // 
            // btnMin4
            // 
            btnMin4.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnMin4.Cursor = Cursors.Hand;
            btnMin4.Image = (Image)resources.GetObject("btnMin4.Image");
            btnMin4.Location = new Point(694, 0);
            btnMin4.Name = "btnMin4";
            btnMin4.Padding = new Padding(2);
            btnMin4.Size = new Size(29, 27);
            btnMin4.SizeMode = PictureBoxSizeMode.StretchImage;
            btnMin4.TabIndex = 94;
            btnMin4.TabStop = false;
            btnMin4.Click += btnMin4_Click;
            // 
            // txtBoxLesiones
            // 
            txtBoxLesiones.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            txtBoxLesiones.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtBoxLesiones.Location = new Point(391, 38);
            txtBoxLesiones.Margin = new Padding(3, 2, 3, 2);
            txtBoxLesiones.Name = "txtBoxLesiones";
            txtBoxLesiones.Size = new Size(329, 26);
            txtBoxLesiones.TabIndex = 97;
            // 
            // label10
            // 
            label10.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label10.AutoSize = true;
            label10.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.Black;
            label10.Location = new Point(11, 38);
            label10.Name = "label10";
            label10.Size = new Size(70, 18);
            label10.TabIndex = 94;
            label10.Text = "Aspecto:";
            // 
            // label9
            // 
            label9.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            label9.Font = new Font("Microsoft Sans Serif", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.Black;
            label9.Location = new Point(11, 6);
            label9.Name = "label9";
            label9.Size = new Size(274, 26);
            label9.TabIndex = 63;
            label9.Text = "Sistema Tegumentario:";
            // 
            // txtboxAspecto
            // 
            txtboxAspecto.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txtboxAspecto.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtboxAspecto.Location = new Point(94, 38);
            txtboxAspecto.Margin = new Padding(3, 2, 3, 2);
            txtboxAspecto.Name = "txtboxAspecto";
            txtboxAspecto.Size = new Size(185, 26);
            txtboxAspecto.TabIndex = 95;
            // 
            // label11
            // 
            label11.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            label11.AutoSize = true;
            label11.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label11.ForeColor = Color.Black;
            label11.Location = new Point(304, 40);
            label11.Name = "label11";
            label11.Size = new Size(76, 18);
            label11.TabIndex = 96;
            label11.Text = "Lesiones:";
            // 
            // label12
            // 
            label12.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label12.AutoSize = true;
            label12.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label12.ForeColor = Color.Black;
            label12.Location = new Point(11, 67);
            label12.Name = "label12";
            label12.Size = new Size(74, 18);
            label12.TabIndex = 98;
            label12.Text = "Alopecia:";
            // 
            // txtBoxAlopecia
            // 
            txtBoxAlopecia.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txtBoxAlopecia.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtBoxAlopecia.Location = new Point(94, 65);
            txtBoxAlopecia.Margin = new Padding(3, 2, 3, 2);
            txtBoxAlopecia.Name = "txtBoxAlopecia";
            txtBoxAlopecia.Size = new Size(185, 26);
            txtBoxAlopecia.TabIndex = 99;
            // 
            // label13
            // 
            label13.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            label13.AutoSize = true;
            label13.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label13.ForeColor = Color.Black;
            label13.Location = new Point(304, 67);
            label13.Name = "label13";
            label13.Size = new Size(79, 18);
            label13.TabIndex = 100;
            label13.Text = "Parásitos:";
            // 
            // txtBoxParasitos
            // 
            txtBoxParasitos.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            txtBoxParasitos.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtBoxParasitos.Location = new Point(391, 65);
            txtBoxParasitos.Margin = new Padding(3, 2, 3, 2);
            txtBoxParasitos.Name = "txtBoxParasitos";
            txtBoxParasitos.Size = new Size(329, 26);
            txtBoxParasitos.TabIndex = 101;
            // 
            // button1
            // 
            button1.AutoSize = true;
            button1.BackColor = Color.FromArgb(0, 126, 249);
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Nirmala UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.Location = new Point(11, 886);
            button1.Margin = new Padding(3, 2, 3, 2);
            button1.Name = "button1";
            button1.Size = new Size(140, 29);
            button1.TabIndex = 198;
            button1.Text = "Ver examen fisico";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // cbEditar
            // 
            cbEditar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            cbEditar.AutoSize = true;
            cbEditar.ForeColor = Color.Black;
            cbEditar.Location = new Point(451, 891);
            cbEditar.Margin = new Padding(3, 2, 3, 2);
            cbEditar.Name = "cbEditar";
            cbEditar.Size = new Size(113, 19);
            cbEditar.TabIndex = 197;
            cbEditar.Text = "Habilitar Edicion";
            cbEditar.UseVisualStyleBackColor = true;
            cbEditar.CheckedChanged += cbEditar_CheckedChanged;
            // 
            // btnNewConsulta
            // 
            btnNewConsulta.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnNewConsulta.AutoSize = true;
            btnNewConsulta.BackColor = Color.FromArgb(0, 126, 249);
            btnNewConsulta.FlatAppearance.BorderSize = 0;
            btnNewConsulta.FlatStyle = FlatStyle.Flat;
            btnNewConsulta.Font = new Font("Nirmala UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnNewConsulta.ForeColor = Color.White;
            btnNewConsulta.Location = new Point(577, 886);
            btnNewConsulta.Margin = new Padding(3, 2, 3, 2);
            btnNewConsulta.Name = "btnNewConsulta";
            btnNewConsulta.Size = new Size(140, 29);
            btnNewConsulta.TabIndex = 196;
            btnNewConsulta.Text = "Agregar consulta";
            btnNewConsulta.UseVisualStyleBackColor = false;
            btnNewConsulta.Click += btnNewConsulta_Click;
            // 
            // label55
            // 
            label55.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label55.AutoSize = true;
            label55.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label55.ForeColor = Color.Black;
            label55.Location = new Point(10, 50);
            label55.Name = "label55";
            label55.Size = new Size(141, 18);
            label55.TabIndex = 94;
            label55.Text = "Motivo de consulta:";
            // 
            // txtBoxMotivoConsulta
            // 
            txtBoxMotivoConsulta.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txtBoxMotivoConsulta.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtBoxMotivoConsulta.Location = new Point(165, 48);
            txtBoxMotivoConsulta.Margin = new Padding(3, 2, 3, 2);
            txtBoxMotivoConsulta.Name = "txtBoxMotivoConsulta";
            txtBoxMotivoConsulta.Size = new Size(195, 26);
            txtBoxMotivoConsulta.TabIndex = 84;
            // 
            // timer1
            // 
            timer1.Interval = 1;
            timer1.Tick += timer1_Tick;
            // 
            // timer2
            // 
            timer2.Interval = 1;
            timer2.Tick += timer2_Tick;
            // 
            // timer3
            // 
            timer3.Interval = 5;
            timer3.Tick += timer3_Tick;
            // 
            // timer4
            // 
            timer4.Interval = 5;
            timer4.Tick += timer4_Tick;
            // 
            // timer5
            // 
            timer5.Interval = 5;
            timer5.Tick += timer5_Tick;
            // 
            // timer6
            // 
            timer6.Interval = 5;
            timer6.Tick += timer6_Tick;
            // 
            // timer7
            // 
            timer7.Interval = 5;
            timer7.Tick += timer7_Tick;
            // 
            // timer8
            // 
            timer8.Interval = 5;
            timer8.Tick += timer8_Tick;
            // 
            // timer9
            // 
            timer9.Interval = 5;
            timer9.Tick += timer9_Tick;
            // 
            // ExpNuevaConsulta
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoScroll = true;
            BackColor = Color.White;
            ClientSize = new Size(772, 542);
            Controls.Add(txtBoxMotivoConsulta);
            Controls.Add(label55);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(lblNombrePaciente);
            Controls.Add(lblDatosPaciente);
            ForeColor = Color.Black;
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 2, 3, 2);
            Name = "ExpNuevaConsulta";
            Text = "ExpNuevaConsulta";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)btnMin1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)btnMin2).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel10.ResumeLayout(false);
            panel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)btnMin10).EndInit();
            panel9.ResumeLayout(false);
            panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)btnMin9).EndInit();
            panel8.ResumeLayout(false);
            panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)btnMin8).EndInit();
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)btnMin7).EndInit();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)btnMin6).EndInit();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)btnMin5).EndInit();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)btnMin4).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNombrePaciente;
        private Label lblDatosPaciente;
        private CheckBox checkVacuna;
        private CheckBox checkRabia;
        private CheckBox checkQuintuple;
        private CheckBox checkParvovirus;
        private CheckBox checkGiardia;
        private CheckBox checkTriFelina;
        private CheckBox checkBordetella;
        private CheckBox checkLeucemia;
        private Label labelOtros;
        private TextBox textBox2;
        private Panel panel1;
        private DateTimePicker dateTimePicker1;
        private CheckBox checkParasitos;
        private Label labelParasitos;
        private TextBox textBox1;
        private Label label1;
        private DateTimePicker dateTimePicker2;
        private CheckBox checkGarrapatas;
        private Label label2;
        private TextBox txtMedicina;
        private Label labelMedi;
        private Panel panel2;
        private TextBox textBox3;
        private Label label3;
        private DateTimePicker dateTimePicker3;
        private CheckBox checkBox1;
        private TextBox textBox4;
        private Label label5;
        private DateTimePicker dateTimePicker4;
        private CheckBox checkAcceso;
        private CheckBox checkBox3;
        private TextBox txtboxAspecto;
        private CheckBox checkBox4;
        private Label labelTenencia;
        private TextBox txtBoxDieta;
        private Label label6;
        private TextBox txtEnfermedades;
        private Label label4;
        private CheckBox checkBox5;
        private CheckBox checkBox6;
        private CheckBox checkBox7;
        private CheckBox checkBox8;
        private CheckBox checkBox9;
        private CheckBox checkBox10;
        private TextBox textBox6;
        private Label label7;
        private TextBox txtBoxTenencia;
        private TextBox txtBoxMascotas;
        private Label label8;
        private Panel panel3;
        private Label label9;
        private TextBox txtBoxMovimiento;
        private Label label17;
        private Label label18;
        private TextBox txtBoxParasitos;
        private Label label13;
        private TextBox txtBoxAlopecia;
        private Label label12;
        private TextBox txtBoxLesiones;
        private Label label11;
        private Label label10;
        private TextBox textBox5;
        private Label label14;
        private TextBox textBox8;
        private Label label16;
        private TextBox textBox9;
        private Label label19;
        private Label label20;
        private TextBox textBox7;
        private Label label15;
        private CheckBox checkBox2;
        private Label label23;
        private TextBox textBox10;
        private Label label21;
        private CheckBox checkBox11;
        private TextBox textBox11;
        private Label label22;
        private TextBox textBox13;
        private Label label24;
        private TextBox textBox14;
        private Label label25;
        private TextBox textBox15;
        private Label label26;
        private TextBox textBox16;
        private Label label27;
        private Label label28;
        private TextBox textBox12;
        private TextBox textBox17;
        private Label label29;
        private TextBox textBox18;
        private Label label30;
        private TextBox textBox19;
        private Label label31;
        private TextBox textBox21;
        private Label label33;
        private Label label34;
        private TextBox textBox20;
        private Label label32;
        private TextBox textBox22;
        private Label label35;
        private TextBox textBox24;
        private Label label37;
        private TextBox textBox26;
        private Label label39;
        private TextBox textBox27;
        private Label label40;
        private Label label41;
        private TextBox textBox23;
        private Label label36;
        private TextBox textBox33;
        private Label label48;
        private TextBox textBox25;
        private Label label38;
        private TextBox textBox28;
        private Label label42;
        private TextBox textBox29;
        private Label label43;
        private CheckBox checkBox12;
        private TextBox textBox30;
        private Label label44;
        private CheckBox checkBox13;
        private TextBox textBox31;
        private Label label45;
        private TextBox textBox32;
        private Label label46;
        private Label label47;
        private TextBox textBox35;
        private Label label50;
        private TextBox textBox36;
        private Label label51;
        private TextBox textBox34;
        private Label label49;
        private TextBox textBox37;
        private Label label52;
        private TextBox textBox38;
        private Label label53;
        private TextBox textBox39;
        private Label label54;
        private Button btnNewConsulta;
        private CheckBox cbEditar;
        private Button button1;
        private Label label55;
        private TextBox txtBoxMotivoConsulta;
        private PictureBox btnMin1;
        private System.Windows.Forms.Timer timer1;
        private PictureBox btnMin2;
        private System.Windows.Forms.Timer timer2;
        private Panel panel4;
        private Panel panel5;
        private Panel panel6;
        private Panel panel7;
        private Panel panel8;
        private Panel panel9;
        private Panel panel10;
        private PictureBox btnMin8;
        private PictureBox btnMin9;
        private PictureBox btnMin10;
        private PictureBox pictureBox2;
        private PictureBox btnMin7;
        private PictureBox btnMin6;
        private PictureBox btnMin5;
        private PictureBox btnMin4;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Timer timer4;
        private System.Windows.Forms.Timer timer5;
        private System.Windows.Forms.Timer timer6;
        private System.Windows.Forms.Timer timer7;
        private System.Windows.Forms.Timer timer8;
        private System.Windows.Forms.Timer timer9;
    }
}