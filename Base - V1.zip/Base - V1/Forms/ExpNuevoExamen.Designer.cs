﻿namespace Base___V1
{
    partial class ExpNuevoExamen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNombrePaciente = new Label();
            lblDatosPaciente = new Label();
            panel2 = new Panel();
            textBox25 = new TextBox();
            label23 = new Label();
            textBox19 = new TextBox();
            label21 = new Label();
            textBox20 = new TextBox();
            label22 = new Label();
            textBox16 = new TextBox();
            label18 = new Label();
            textBox17 = new TextBox();
            label19 = new Label();
            textBox18 = new TextBox();
            label20 = new Label();
            textBox13 = new TextBox();
            label15 = new Label();
            textBox14 = new TextBox();
            label16 = new Label();
            textBox15 = new TextBox();
            label17 = new Label();
            textBox4 = new TextBox();
            label7 = new Label();
            textBox6 = new TextBox();
            label8 = new Label();
            textBox10 = new TextBox();
            label12 = new Label();
            textBox12 = new TextBox();
            label14 = new Label();
            textBox9 = new TextBox();
            label4 = new Label();
            textBox11 = new TextBox();
            label13 = new Label();
            txtBoxLesiones = new TextBox();
            textBox5 = new TextBox();
            label11 = new Label();
            label5 = new Label();
            txtboxAspecto = new TextBox();
            label10 = new Label();
            textBox7 = new TextBox();
            label6 = new Label();
            textBox8 = new TextBox();
            label9 = new Label();
            textBox2 = new TextBox();
            label2 = new Label();
            textBox1 = new TextBox();
            label1 = new Label();
            txtBoxTenencia = new TextBox();
            textBox3 = new TextBox();
            label3 = new Label();
            labelTenencia = new Label();
            panel1 = new Panel();
            label25 = new Label();
            textBox24 = new TextBox();
            textBox22 = new TextBox();
            label24 = new Label();
            panel3 = new Panel();
            cbEditar = new CheckBox();
            btnNewExamen = new Button();
            textBox21 = new TextBox();
            label27 = new Label();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            panel3.SuspendLayout();
            SuspendLayout();
            // 
            // lblNombrePaciente
            // 
            lblNombrePaciente.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblNombrePaciente.ForeColor = Color.Black;
            lblNombrePaciente.Location = new Point(284, 7);
            lblNombrePaciente.Name = "lblNombrePaciente";
            lblNombrePaciente.Size = new Size(340, 32);
            lblNombrePaciente.TabIndex = 65;
            lblNombrePaciente.Text = "Nombre del chucho";
            // 
            // lblDatosPaciente
            // 
            lblDatosPaciente.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblDatosPaciente.ForeColor = Color.Black;
            lblDatosPaciente.Location = new Point(10, 7);
            lblDatosPaciente.Name = "lblDatosPaciente";
            lblDatosPaciente.Size = new Size(352, 32);
            lblDatosPaciente.TabIndex = 64;
            lblDatosPaciente.Text = "Nueva examen fisico:";
            // 
            // panel2
            // 
            panel2.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel2.AutoScroll = true;
            panel2.BackColor = Color.WhiteSmoke;
            panel2.Controls.Add(textBox25);
            panel2.Controls.Add(label23);
            panel2.Controls.Add(textBox19);
            panel2.Controls.Add(label21);
            panel2.Controls.Add(textBox20);
            panel2.Controls.Add(label22);
            panel2.Controls.Add(textBox16);
            panel2.Controls.Add(label18);
            panel2.Controls.Add(textBox17);
            panel2.Controls.Add(label19);
            panel2.Controls.Add(textBox18);
            panel2.Controls.Add(label20);
            panel2.Controls.Add(textBox13);
            panel2.Controls.Add(label15);
            panel2.Controls.Add(textBox14);
            panel2.Controls.Add(label16);
            panel2.Controls.Add(textBox15);
            panel2.Controls.Add(label17);
            panel2.Controls.Add(textBox4);
            panel2.Controls.Add(label7);
            panel2.Controls.Add(textBox6);
            panel2.Controls.Add(label8);
            panel2.Controls.Add(textBox10);
            panel2.Controls.Add(label12);
            panel2.Controls.Add(textBox12);
            panel2.Controls.Add(label14);
            panel2.Controls.Add(textBox9);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(textBox11);
            panel2.Controls.Add(label13);
            panel2.Controls.Add(txtBoxLesiones);
            panel2.Controls.Add(textBox5);
            panel2.Controls.Add(label11);
            panel2.Controls.Add(label5);
            panel2.Controls.Add(txtboxAspecto);
            panel2.Controls.Add(label10);
            panel2.Controls.Add(textBox7);
            panel2.Controls.Add(label6);
            panel2.Controls.Add(textBox8);
            panel2.Controls.Add(label9);
            panel2.Controls.Add(textBox2);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(textBox1);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(txtBoxTenencia);
            panel2.Controls.Add(textBox3);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(labelTenencia);
            panel2.Location = new Point(10, 50);
            panel2.Margin = new Padding(3, 2, 3, 2);
            panel2.MaximumSize = new Size(0, 442);
            panel2.MinimumSize = new Size(729, 396);
            panel2.Name = "panel2";
            panel2.Size = new Size(729, 442);
            panel2.TabIndex = 85;
            // 
            // textBox25
            // 
            textBox25.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox25.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox25.Location = new Point(16, 362);
            textBox25.Margin = new Padding(3, 2, 3, 2);
            textBox25.Multiline = true;
            textBox25.Name = "textBox25";
            textBox25.Size = new Size(698, 53);
            textBox25.TabIndex = 135;
            // 
            // label23
            // 
            label23.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label23.AutoSize = true;
            label23.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label23.ForeColor = Color.Black;
            label23.Location = new Point(16, 342);
            label23.Name = "label23";
            label23.Size = new Size(159, 18);
            label23.TabIndex = 132;
            label23.Text = "Otras Observaciones:";
            // 
            // textBox19
            // 
            textBox19.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox19.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox19.Location = new Point(578, 310);
            textBox19.Margin = new Padding(3, 2, 3, 2);
            textBox19.Name = "textBox19";
            textBox19.Size = new Size(137, 26);
            textBox19.TabIndex = 131;
            // 
            // label21
            // 
            label21.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label21.AutoSize = true;
            label21.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label21.ForeColor = Color.Black;
            label21.Location = new Point(447, 313);
            label21.Name = "label21";
            label21.Size = new Size(119, 18);
            label21.TabIndex = 130;
            label21.Text = "Condi. corporal:";
            // 
            // textBox20
            // 
            textBox20.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            textBox20.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox20.Location = new Point(75, 310);
            textBox20.Margin = new Padding(3, 2, 3, 2);
            textBox20.Name = "textBox20";
            textBox20.Size = new Size(367, 26);
            textBox20.TabIndex = 129;
            // 
            // label22
            // 
            label22.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label22.AutoSize = true;
            label22.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label22.ForeColor = Color.Black;
            label22.Location = new Point(15, 313);
            label22.Name = "label22";
            label22.Size = new Size(59, 18);
            label22.TabIndex = 128;
            label22.Text = "Dedos:";
            // 
            // textBox16
            // 
            textBox16.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            textBox16.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox16.Location = new Point(575, 281);
            textBox16.Margin = new Padding(3, 2, 3, 2);
            textBox16.Name = "textBox16";
            textBox16.Size = new Size(140, 26);
            textBox16.TabIndex = 127;
            // 
            // label18
            // 
            label18.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            label18.AutoSize = true;
            label18.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label18.ForeColor = Color.Black;
            label18.Location = new Point(481, 284);
            label18.Name = "label18";
            label18.Size = new Size(85, 18);
            label18.TabIndex = 126;
            label18.Text = "Testi/Vulva:";
            // 
            // textBox17
            // 
            textBox17.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox17.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox17.Location = new Point(369, 281);
            textBox17.Margin = new Padding(3, 2, 3, 2);
            textBox17.Name = "textBox17";
            textBox17.Size = new Size(107, 26);
            textBox17.TabIndex = 125;
            // 
            // label19
            // 
            label19.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label19.AutoSize = true;
            label19.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label19.ForeColor = Color.Black;
            label19.Location = new Point(226, 284);
            label19.Name = "label19";
            label19.Size = new Size(116, 18);
            label19.TabIndex = 124;
            label19.Text = "Prepucio/Pene:";
            // 
            // textBox18
            // 
            textBox18.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            textBox18.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox18.Location = new Point(75, 281);
            textBox18.Margin = new Padding(3, 2, 3, 2);
            textBox18.Name = "textBox18";
            textBox18.Size = new Size(140, 26);
            textBox18.TabIndex = 123;
            // 
            // label20
            // 
            label20.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label20.AutoSize = true;
            label20.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label20.ForeColor = Color.Black;
            label20.Location = new Point(16, 284);
            label20.Name = "label20";
            label20.Size = new Size(56, 18);
            label20.TabIndex = 122;
            label20.Text = "Vejiga:";
            // 
            // textBox13
            // 
            textBox13.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            textBox13.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox13.Location = new Point(575, 254);
            textBox13.Margin = new Padding(3, 2, 3, 2);
            textBox13.Name = "textBox13";
            textBox13.Size = new Size(140, 26);
            textBox13.TabIndex = 121;
            // 
            // label15
            // 
            label15.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            label15.AutoSize = true;
            label15.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label15.ForeColor = Color.Black;
            label15.Location = new Point(501, 256);
            label15.Name = "label15";
            label15.Size = new Size(69, 18);
            label15.TabIndex = 120;
            label15.Text = "Intestino:";
            // 
            // textBox14
            // 
            textBox14.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox14.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox14.Location = new Point(369, 254);
            textBox14.Margin = new Padding(3, 2, 3, 2);
            textBox14.Name = "textBox14";
            textBox14.Size = new Size(107, 26);
            textBox14.TabIndex = 119;
            // 
            // label16
            // 
            label16.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label16.AutoSize = true;
            label16.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label16.ForeColor = Color.Black;
            label16.Location = new Point(279, 260);
            label16.Name = "label16";
            label16.Size = new Size(63, 18);
            label16.TabIndex = 118;
            label16.Text = "Higado:";
            // 
            // textBox15
            // 
            textBox15.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            textBox15.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox15.Location = new Point(75, 254);
            textBox15.Margin = new Padding(3, 2, 3, 2);
            textBox15.Name = "textBox15";
            textBox15.Size = new Size(140, 26);
            textBox15.TabIndex = 117;
            // 
            // label17
            // 
            label17.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label17.AutoSize = true;
            label17.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label17.ForeColor = Color.Black;
            label17.Location = new Point(16, 256);
            label17.Name = "label17";
            label17.Size = new Size(52, 18);
            label17.TabIndex = 116;
            label17.Text = "Riñon:";
            // 
            // textBox4
            // 
            textBox4.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox4.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox4.Location = new Point(594, 224);
            textBox4.Margin = new Padding(3, 2, 3, 2);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(120, 26);
            textBox4.TabIndex = 115;
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label7.AutoSize = true;
            label7.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.Black;
            label7.Location = new Point(463, 227);
            label7.Name = "label7";
            label7.Size = new Size(125, 18);
            label7.TabIndex = 114;
            label7.Text = "Palmopercusión:";
            // 
            // textBox6
            // 
            textBox6.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            textBox6.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox6.Location = new Point(136, 224);
            textBox6.Margin = new Padding(3, 2, 3, 2);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(307, 26);
            textBox6.TabIndex = 113;
            // 
            // label8
            // 
            label8.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label8.AutoSize = true;
            label8.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.Black;
            label8.Location = new Point(18, 226);
            label8.Name = "label8";
            label8.Size = new Size(114, 18);
            label8.TabIndex = 112;
            label8.Text = "Plp.Abdominal:";
            // 
            // textBox10
            // 
            textBox10.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox10.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox10.Location = new Point(594, 195);
            textBox10.Margin = new Padding(3, 2, 3, 2);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(120, 26);
            textBox10.TabIndex = 111;
            // 
            // label12
            // 
            label12.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label12.AutoSize = true;
            label12.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label12.ForeColor = Color.Black;
            label12.Location = new Point(481, 197);
            label12.Name = "label12";
            label12.Size = new Size(107, 18);
            label12.TabIndex = 110;
            label12.Text = "Deshidratado:";
            // 
            // textBox12
            // 
            textBox12.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            textBox12.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox12.Location = new Point(136, 195);
            textBox12.Margin = new Padding(3, 2, 3, 2);
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(307, 26);
            textBox12.TabIndex = 109;
            // 
            // label14
            // 
            label14.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label14.AutoSize = true;
            label14.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label14.ForeColor = Color.Black;
            label14.Location = new Point(16, 197);
            label14.Name = "label14";
            label14.Size = new Size(51, 18);
            label14.TabIndex = 108;
            label14.Text = "TLLC:";
            // 
            // textBox9
            // 
            textBox9.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox9.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox9.Location = new Point(578, 133);
            textBox9.Margin = new Padding(3, 2, 3, 2);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(137, 26);
            textBox9.TabIndex = 107;
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Black;
            label4.Location = new Point(481, 135);
            label4.Name = "label4";
            label4.Size = new Size(48, 18);
            label4.TabIndex = 106;
            label4.Text = "Tonsi:";
            // 
            // textBox11
            // 
            textBox11.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            textBox11.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox11.Location = new Point(136, 133);
            textBox11.Margin = new Padding(3, 2, 3, 2);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(307, 26);
            textBox11.TabIndex = 105;
            // 
            // label13
            // 
            label13.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label13.AutoSize = true;
            label13.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label13.ForeColor = Color.Black;
            label13.Location = new Point(16, 135);
            label13.Name = "label13";
            label13.Size = new Size(85, 18);
            label13.TabIndex = 104;
            label13.Text = "Dentadura:";
            // 
            // txtBoxLesiones
            // 
            txtBoxLesiones.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txtBoxLesiones.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtBoxLesiones.Location = new Point(578, 100);
            txtBoxLesiones.Margin = new Padding(3, 2, 3, 2);
            txtBoxLesiones.Name = "txtBoxLesiones";
            txtBoxLesiones.Size = new Size(137, 26);
            txtBoxLesiones.TabIndex = 101;
            // 
            // textBox5
            // 
            textBox5.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            textBox5.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox5.Location = new Point(575, 68);
            textBox5.Margin = new Padding(3, 2, 3, 2);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(140, 26);
            textBox5.TabIndex = 103;
            // 
            // label11
            // 
            label11.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label11.AutoSize = true;
            label11.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label11.ForeColor = Color.Black;
            label11.Location = new Point(481, 102);
            label11.Name = "label11";
            label11.Size = new Size(75, 18);
            label11.TabIndex = 100;
            label11.Text = "Mucosas:";
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            label5.AutoSize = true;
            label5.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.Black;
            label5.Location = new Point(515, 70);
            label5.Name = "label5";
            label5.Size = new Size(51, 18);
            label5.TabIndex = 102;
            label5.Text = "Pulso:";
            // 
            // txtboxAspecto
            // 
            txtboxAspecto.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            txtboxAspecto.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtboxAspecto.Location = new Point(136, 102);
            txtboxAspecto.Margin = new Padding(3, 2, 3, 2);
            txtboxAspecto.Name = "txtboxAspecto";
            txtboxAspecto.Size = new Size(307, 26);
            txtboxAspecto.TabIndex = 99;
            // 
            // label10
            // 
            label10.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label10.AutoSize = true;
            label10.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.Black;
            label10.Location = new Point(16, 102);
            label10.Name = "label10";
            label10.Size = new Size(87, 18);
            label10.TabIndex = 98;
            label10.Text = "Anisocoria:";
            // 
            // textBox7
            // 
            textBox7.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox7.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox7.Location = new Point(369, 68);
            textBox7.Margin = new Padding(3, 2, 3, 2);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(137, 26);
            textBox7.TabIndex = 101;
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label6.AutoSize = true;
            label6.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.Black;
            label6.Location = new Point(225, 70);
            label6.Name = "label6";
            label6.Size = new Size(111, 18);
            label6.TabIndex = 100;
            label6.Text = "Reflejo pupilar:";
            // 
            // textBox8
            // 
            textBox8.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            textBox8.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox8.Location = new Point(75, 68);
            textBox8.Margin = new Padding(3, 2, 3, 2);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(140, 26);
            textBox8.TabIndex = 99;
            // 
            // label9
            // 
            label9.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label9.AutoSize = true;
            label9.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.Black;
            label9.Location = new Point(16, 70);
            label9.Name = "label9";
            label9.Size = new Size(50, 18);
            label9.TabIndex = 98;
            label9.Text = "Temp:";
            // 
            // textBox2
            // 
            textBox2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            textBox2.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox2.Location = new Point(575, 38);
            textBox2.Margin = new Padding(3, 2, 3, 2);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(140, 26);
            textBox2.TabIndex = 97;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(515, 40);
            label2.Name = "label2";
            label2.Size = new Size(33, 18);
            label2.TabIndex = 96;
            label2.Text = "FR:";
            // 
            // textBox1
            // 
            textBox1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox1.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox1.Location = new Point(369, 38);
            textBox1.Margin = new Padding(3, 2, 3, 2);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(137, 26);
            textBox1.TabIndex = 95;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(225, 40);
            label1.Name = "label1";
            label1.Size = new Size(132, 18);
            label1.TabIndex = 94;
            label1.Text = "Sonido-Cardiaco:";
            // 
            // txtBoxTenencia
            // 
            txtBoxTenencia.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            txtBoxTenencia.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtBoxTenencia.Location = new Point(75, 38);
            txtBoxTenencia.Margin = new Padding(3, 2, 3, 2);
            txtBoxTenencia.Name = "txtBoxTenencia";
            txtBoxTenencia.Size = new Size(140, 26);
            txtBoxTenencia.TabIndex = 89;
            // 
            // textBox3
            // 
            textBox3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox3.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox3.Location = new Point(224, 166);
            textBox3.Margin = new Padding(3, 2, 3, 2);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(490, 26);
            textBox3.TabIndex = 83;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Black;
            label3.Location = new Point(16, 168);
            label3.Name = "label3";
            label3.Size = new Size(184, 18);
            label3.TabIndex = 82;
            label3.Text = "Refl. Tusigeno/Deglusion:";
            // 
            // labelTenencia
            // 
            labelTenencia.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            labelTenencia.AutoSize = true;
            labelTenencia.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelTenencia.ForeColor = Color.Black;
            labelTenencia.Location = new Point(16, 40);
            labelTenencia.Name = "labelTenencia";
            labelTenencia.Size = new Size(34, 18);
            labelTenencia.TabIndex = 72;
            labelTenencia.Text = "FC:";
            // 
            // panel1
            // 
            panel1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel1.BackColor = Color.WhiteSmoke;
            panel1.Controls.Add(label25);
            panel1.Controls.Add(textBox24);
            panel1.Controls.Add(textBox22);
            panel1.Controls.Add(label24);
            panel1.Location = new Point(10, 510);
            panel1.Margin = new Padding(3, 2, 3, 2);
            panel1.MaximumSize = new Size(0, 177);
            panel1.MinimumSize = new Size(732, 177);
            panel1.Name = "panel1";
            panel1.Size = new Size(732, 177);
            panel1.TabIndex = 86;
            // 
            // label25
            // 
            label25.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            label25.AutoSize = true;
            label25.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label25.ForeColor = Color.Black;
            label25.Location = new Point(301, 95);
            label25.Name = "label25";
            label25.Size = new Size(114, 18);
            label25.TabIndex = 136;
            label25.Text = "Dx. Diferencial:";
            label25.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // textBox24
            // 
            textBox24.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox24.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox24.Location = new Point(23, 115);
            textBox24.Margin = new Padding(3, 2, 3, 2);
            textBox24.Multiline = true;
            textBox24.Name = "textBox24";
            textBox24.Size = new Size(700, 46);
            textBox24.TabIndex = 134;
            // 
            // textBox22
            // 
            textBox22.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox22.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox22.Location = new Point(21, 34);
            textBox22.Margin = new Padding(3, 2, 3, 2);
            textBox22.Multiline = true;
            textBox22.Name = "textBox22";
            textBox22.Size = new Size(701, 46);
            textBox22.TabIndex = 135;
            // 
            // label24
            // 
            label24.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            label24.AutoSize = true;
            label24.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label24.ForeColor = Color.Black;
            label24.Location = new Point(299, 15);
            label24.Name = "label24";
            label24.Size = new Size(112, 18);
            label24.TabIndex = 134;
            label24.Text = "Dx. Presuntivo:";
            label24.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            panel3.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel3.BackColor = Color.WhiteSmoke;
            panel3.Controls.Add(cbEditar);
            panel3.Controls.Add(btnNewExamen);
            panel3.Controls.Add(textBox21);
            panel3.Controls.Add(label27);
            panel3.Location = new Point(10, 675);
            panel3.Margin = new Padding(3, 2, 3, 2);
            panel3.MinimumSize = new Size(732, 120);
            panel3.Name = "panel3";
            panel3.Size = new Size(732, 130);
            panel3.TabIndex = 138;
            // 
            // cbEditar
            // 
            cbEditar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            cbEditar.AutoSize = true;
            cbEditar.ForeColor = Color.Black;
            cbEditar.Location = new Point(461, 100);
            cbEditar.Margin = new Padding(3, 2, 3, 2);
            cbEditar.Name = "cbEditar";
            cbEditar.Size = new Size(113, 19);
            cbEditar.TabIndex = 198;
            cbEditar.Text = "Habilitar Edicion";
            cbEditar.UseVisualStyleBackColor = true;
            cbEditar.CheckedChanged += cbEditar_CheckedChanged;
            // 
            // btnNewExamen
            // 
            btnNewExamen.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnNewExamen.BackColor = Color.FromArgb(0, 126, 249);
            btnNewExamen.FlatAppearance.BorderSize = 0;
            btnNewExamen.FlatStyle = FlatStyle.Flat;
            btnNewExamen.Font = new Font("Nirmala UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnNewExamen.ForeColor = Color.White;
            btnNewExamen.Location = new Point(589, 94);
            btnNewExamen.Margin = new Padding(3, 2, 3, 2);
            btnNewExamen.Name = "btnNewExamen";
            btnNewExamen.Size = new Size(140, 27);
            btnNewExamen.TabIndex = 197;
            btnNewExamen.Text = "Agregar Examen";
            btnNewExamen.UseVisualStyleBackColor = false;
            btnNewExamen.Click += btnNewExamen_Click;
            // 
            // textBox21
            // 
            textBox21.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox21.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox21.Location = new Point(29, 43);
            textBox21.Margin = new Padding(3, 2, 3, 2);
            textBox21.Multiline = true;
            textBox21.Name = "textBox21";
            textBox21.Size = new Size(700, 46);
            textBox21.TabIndex = 137;
            // 
            // label27
            // 
            label27.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            label27.AutoSize = true;
            label27.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label27.ForeColor = Color.Black;
            label27.Location = new Point(262, 14);
            label27.Name = "label27";
            label27.Size = new Size(187, 18);
            label27.TabIndex = 134;
            label27.Text = "Examenes de laboratorio:";
            label27.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // ExpNuevoExamen
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoScroll = true;
            BackColor = Color.White;
            ClientSize = new Size(772, 472);
            Controls.Add(panel3);
            Controls.Add(panel1);
            Controls.Add(panel2);
            Controls.Add(lblNombrePaciente);
            Controls.Add(lblDatosPaciente);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 2, 3, 2);
            MinimumSize = new Size(772, 445);
            Name = "ExpNuevoExamen";
            Text = "ExpNuevoExamen";
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Label lblNombrePaciente;
        private Label lblDatosPaciente;
        private Panel panel2;
        private TextBox txtBoxTenencia;
        private TextBox textBox3;
        private Label label3;
        private Label labelTenencia;
        private TextBox textBox1;
        private Label label1;
        private TextBox textBox5;
        private Label label5;
        private TextBox textBox7;
        private Label label6;
        private TextBox textBox8;
        private Label label9;
        private TextBox textBox2;
        private Label label2;
        private TextBox txtBoxLesiones;
        private Label label11;
        private TextBox txtboxAspecto;
        private Label label10;
        private TextBox textBox9;
        private Label label4;
        private TextBox textBox11;
        private Label label13;
        private TextBox textBox13;
        private Label label15;
        private TextBox textBox14;
        private Label label16;
        private TextBox textBox15;
        private Label label17;
        private TextBox textBox4;
        private Label label7;
        private TextBox textBox6;
        private Label label8;
        private TextBox textBox10;
        private Label label12;
        private TextBox textBox12;
        private Label label14;
        private TextBox textBox16;
        private Label label18;
        private TextBox textBox17;
        private Label label19;
        private TextBox textBox18;
        private Label label20;
        private TextBox textBox19;
        private Label label21;
        private TextBox textBox20;
        private Label label22;
        private Label label23;
        private Panel panel1;
        private TextBox textBox22;
        private Label label24;
        private Label label25;
        private Panel panel3;
        private Label label27;
        private TextBox textBox25;
        private TextBox textBox24;
        private TextBox textBox21;
        private Button btnNewExamen;
        private CheckBox cbEditar;
    }
}