﻿namespace Base___V1
{
	partial class MenuAddPaciente
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            btnCapturar = new Button();
            label12 = new Label();
            pb2 = new PictureBox();
            label13 = new Label();
            txboxTelefono = new TextBox();
            label14 = new Label();
            txboxCorreo = new TextBox();
            label11 = new Label();
            txboxDireccion = new TextBox();
            label10 = new Label();
            txboxPropietario = new TextBox();
            label8 = new Label();
            txboxSenias = new TextBox();
            comboBoxSexo = new ComboBox();
            label5 = new Label();
            label6 = new Label();
            txboxColor = new TextBox();
            label7 = new Label();
            txboxEdad = new TextBox();
            label4 = new Label();
            label3 = new Label();
            txboxRaza = new TextBox();
            txboxEspecie = new TextBox();
            label2 = new Label();
            txboxPaciente = new TextBox();
            label1 = new Label();
            IblTittle = new Label();
            btnAgregar = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pb2).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            panel1.AutoScroll = true;
            panel1.BackColor = Color.White;
            panel1.Controls.Add(btnCapturar);
            panel1.Controls.Add(label12);
            panel1.Controls.Add(pb2);
            panel1.Controls.Add(label13);
            panel1.Controls.Add(txboxTelefono);
            panel1.Controls.Add(label14);
            panel1.Controls.Add(txboxCorreo);
            panel1.Controls.Add(label11);
            panel1.Controls.Add(txboxDireccion);
            panel1.Controls.Add(label10);
            panel1.Controls.Add(txboxPropietario);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(txboxSenias);
            panel1.Controls.Add(comboBoxSexo);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(txboxColor);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(txboxEdad);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(txboxRaza);
            panel1.Controls.Add(txboxEspecie);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(txboxPaciente);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(IblTittle);
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(3, 2, 3, 2);
            panel1.Name = "panel1";
            panel1.Size = new Size(814, 608);
            panel1.TabIndex = 0;
            panel1.Paint += panel1_Paint;
            // 
            // btnCapturar
            // 
            btnCapturar.AutoSize = true;
            btnCapturar.BackColor = Color.Gray;
            btnCapturar.Cursor = Cursors.Hand;
            btnCapturar.FlatAppearance.BorderSize = 0;
            btnCapturar.FlatStyle = FlatStyle.Flat;
            btnCapturar.Font = new Font("Nirmala UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCapturar.ForeColor = Color.White;
            btnCapturar.Location = new Point(158, 64);
            btnCapturar.Margin = new Padding(3, 2, 3, 2);
            btnCapturar.Name = "btnCapturar";
            btnCapturar.Size = new Size(121, 33);
            btnCapturar.TabIndex = 13;
            btnCapturar.Text = "Capturar";
            btnCapturar.UseVisualStyleBackColor = false;
            btnCapturar.Click += btnCapturar_Click_1;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label12.ForeColor = Color.Black;
            label12.Location = new Point(12, 79);
            label12.Name = "label12";
            label12.Size = new Size(80, 18);
            label12.TabIndex = 40;
            label12.Text = "Fotografia";
            // 
            // pb2
            // 
            pb2.BorderStyle = BorderStyle.FixedSingle;
            pb2.Location = new Point(12, 99);
            pb2.Margin = new Padding(3, 2, 3, 2);
            pb2.Name = "pb2";
            pb2.Size = new Size(267, 177);
            pb2.SizeMode = PictureBoxSizeMode.StretchImage;
            pb2.TabIndex = 39;
            pb2.TabStop = false;
            // 
            // label13
            // 
            label13.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            label13.AutoSize = true;
            label13.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label13.ForeColor = Color.Black;
            label13.Location = new Point(496, 489);
            label13.Name = "label13";
            label13.Size = new Size(70, 18);
            label13.TabIndex = 36;
            label13.Text = "Telefono:";
            // 
            // txboxTelefono
            // 
            txboxTelefono.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            txboxTelefono.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txboxTelefono.Location = new Point(572, 489);
            txboxTelefono.Margin = new Padding(3, 2, 3, 2);
            txboxTelefono.Name = "txboxTelefono";
            txboxTelefono.Size = new Size(234, 26);
            txboxTelefono.TabIndex = 34;
            // 
            // label14
            // 
            label14.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            label14.AutoSize = true;
            label14.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label14.ForeColor = Color.Black;
            label14.Location = new Point(12, 546);
            label14.Name = "label14";
            label14.Size = new Size(61, 18);
            label14.TabIndex = 33;
            label14.Text = "Correo:";
            // 
            // txboxCorreo
            // 
            txboxCorreo.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txboxCorreo.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txboxCorreo.Location = new Point(124, 543);
            txboxCorreo.Margin = new Padding(3, 2, 3, 2);
            txboxCorreo.Name = "txboxCorreo";
            txboxCorreo.Size = new Size(190, 26);
            txboxCorreo.TabIndex = 32;
            // 
            // label11
            // 
            label11.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            label11.AutoSize = true;
            label11.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label11.ForeColor = Color.Black;
            label11.Location = new Point(12, 486);
            label11.Name = "label11";
            label11.Size = new Size(79, 18);
            label11.TabIndex = 31;
            label11.Text = "Dirección:";
            // 
            // txboxDireccion
            // 
            txboxDireccion.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txboxDireccion.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txboxDireccion.Location = new Point(124, 486);
            txboxDireccion.Margin = new Padding(3, 2, 3, 2);
            txboxDireccion.Multiline = true;
            txboxDireccion.Name = "txboxDireccion";
            txboxDireccion.Size = new Size(347, 38);
            txboxDireccion.TabIndex = 30;
            // 
            // label10
            // 
            label10.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            label10.AutoSize = true;
            label10.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.Black;
            label10.Location = new Point(12, 440);
            label10.Name = "label10";
            label10.Size = new Size(90, 18);
            label10.TabIndex = 29;
            label10.Text = "Propietario:";
            // 
            // txboxPropietario
            // 
            txboxPropietario.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txboxPropietario.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txboxPropietario.Location = new Point(124, 438);
            txboxPropietario.Margin = new Padding(3, 2, 3, 2);
            txboxPropietario.Name = "txboxPropietario";
            txboxPropietario.Size = new Size(682, 26);
            txboxPropietario.TabIndex = 28;
            // 
            // label8
            // 
            label8.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label8.AutoSize = true;
            label8.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.Black;
            label8.Location = new Point(21, 291);
            label8.Name = "label8";
            label8.Size = new Size(57, 18);
            label8.TabIndex = 25;
            label8.Text = "Señas:";
            // 
            // txboxSenias
            // 
            txboxSenias.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txboxSenias.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txboxSenias.Location = new Point(84, 291);
            txboxSenias.Margin = new Padding(3, 2, 3, 2);
            txboxSenias.Multiline = true;
            txboxSenias.Name = "txboxSenias";
            txboxSenias.Size = new Size(727, 73);
            txboxSenias.TabIndex = 24;
            // 
            // comboBoxSexo
            // 
            comboBoxSexo.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            comboBoxSexo.Cursor = Cursors.Hand;
            comboBoxSexo.FormattingEnabled = true;
            comboBoxSexo.Items.AddRange(new object[] { "Femenino", "Masculino" });
            comboBoxSexo.Location = new Point(339, 224);
            comboBoxSexo.Margin = new Padding(3, 2, 3, 2);
            comboBoxSexo.Name = "comboBoxSexo";
            comboBoxSexo.Size = new Size(88, 23);
            comboBoxSexo.TabIndex = 23;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label5.AutoSize = true;
            label5.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.Black;
            label5.Location = new Point(516, 224);
            label5.Name = "label5";
            label5.Size = new Size(50, 18);
            label5.TabIndex = 22;
            label5.Text = "Color:";
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label6.AutoSize = true;
            label6.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.Black;
            label6.Location = new Point(285, 224);
            label6.Name = "label6";
            label6.Size = new Size(48, 18);
            label6.TabIndex = 21;
            label6.Text = "Sexo:";
            // 
            // txboxColor
            // 
            txboxColor.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txboxColor.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txboxColor.Location = new Point(572, 221);
            txboxColor.Margin = new Padding(3, 2, 3, 2);
            txboxColor.Name = "txboxColor";
            txboxColor.Size = new Size(162, 26);
            txboxColor.TabIndex = 20;
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            label7.AutoSize = true;
            label7.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.Black;
            label7.Location = new Point(559, 167);
            label7.Name = "label7";
            label7.Size = new Size(50, 18);
            label7.TabIndex = 18;
            label7.Text = "Edad:";
            // 
            // txboxEdad
            // 
            txboxEdad.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            txboxEdad.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txboxEdad.Location = new Point(615, 159);
            txboxEdad.Margin = new Padding(3, 2, 3, 2);
            txboxEdad.Name = "txboxEdad";
            txboxEdad.Size = new Size(196, 26);
            txboxEdad.TabIndex = 17;
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Black;
            label4.Location = new Point(311, 167);
            label4.Name = "label4";
            label4.Size = new Size(48, 18);
            label4.TabIndex = 16;
            label4.Text = "Raza:";
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Black;
            label3.Location = new Point(539, 102);
            label3.Name = "label3";
            label3.Size = new Size(70, 18);
            label3.TabIndex = 15;
            label3.Text = "Especie:";
            // 
            // txboxRaza
            // 
            txboxRaza.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txboxRaza.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txboxRaza.Location = new Point(365, 159);
            txboxRaza.Margin = new Padding(3, 2, 3, 2);
            txboxRaza.Name = "txboxRaza";
            txboxRaza.Size = new Size(168, 26);
            txboxRaza.TabIndex = 14;
            // 
            // txboxEspecie
            // 
            txboxEspecie.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            txboxEspecie.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txboxEspecie.Location = new Point(615, 99);
            txboxEspecie.Margin = new Padding(3, 2, 3, 2);
            txboxEspecie.Name = "txboxEspecie";
            txboxEspecie.Size = new Size(196, 26);
            txboxEspecie.TabIndex = 12;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(285, 99);
            label2.Name = "label2";
            label2.Size = new Size(74, 18);
            label2.TabIndex = 11;
            label2.Text = "Paciente:";
            // 
            // txboxPaciente
            // 
            txboxPaciente.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txboxPaciente.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txboxPaciente.Location = new Point(365, 96);
            txboxPaciente.Margin = new Padding(3, 2, 3, 2);
            txboxPaciente.Name = "txboxPaciente";
            txboxPaciente.Size = new Size(168, 26);
            txboxPaciente.TabIndex = 10;
            // 
            // label1
            // 
            label1.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(21, 25);
            label1.Name = "label1";
            label1.Size = new Size(207, 32);
            label1.TabIndex = 9;
            label1.Text = "Datos paciente";
            // 
            // IblTittle
            // 
            IblTittle.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            IblTittle.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            IblTittle.ForeColor = Color.Black;
            IblTittle.Location = new Point(12, 391);
            IblTittle.Name = "IblTittle";
            IblTittle.Size = new Size(422, 32);
            IblTittle.TabIndex = 8;
            IblTittle.Text = "Datos del propietario";
            // 
            // btnAgregar
            // 
            btnAgregar.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnAgregar.AutoSize = true;
            btnAgregar.BackColor = Color.FromArgb(0, 126, 249);
            btnAgregar.FlatAppearance.BorderSize = 0;
            btnAgregar.FlatStyle = FlatStyle.Flat;
            btnAgregar.Font = new Font("Nirmala UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAgregar.ForeColor = Color.White;
            btnAgregar.Location = new Point(665, 622);
            btnAgregar.Margin = new Padding(3, 2, 3, 2);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(149, 29);
            btnAgregar.TabIndex = 11;
            btnAgregar.Text = "Agregar";
            btnAgregar.UseVisualStyleBackColor = false;
            btnAgregar.Click += btnAgregar_Click;
            // 
            // MenuAddPaciente
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(818, 662);
            Controls.Add(btnAgregar);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 2, 3, 2);
            Name = "MenuAddPaciente";
            Text = "Pantalla3";
            FormClosed += MenuAddPaciente_FormClosed;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pb2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
		private Label label2;
		private Label label1;
		private Label IblTittle;
		private ComboBox comboBoxSexo;
		private Label label5;
		private Label label6;
		private TextBox txboxColor;
		private TextBox txboxEdad;
		private Label label4;
		private Label label3;
		private TextBox txboxRaza;
		private TextBox txboxEspecie;
		private Label label8;
		private TextBox txboxSenias;
		private Label label7;
		private TextBox txboxPaciente;
		private Label label13;
		private TextBox txboxTelefono;
		private Label label14;
		private TextBox txboxCorreo;
		private Label label11;
		private TextBox txboxDireccion;
		private Label label10;
		private TextBox txboxPropietario;
		private Button btnAgregar;
		private Button btnCapturar;
		private Label label12;
		private PictureBox pb2;
	}
}