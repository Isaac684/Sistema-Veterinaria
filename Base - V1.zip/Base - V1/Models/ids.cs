﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Base___V1.Models
{
    public class ids
    {
        public int idMascota { get;set; }
        public int idDueño {  get;set; }

        public ids()
        {
        }
    }
}
